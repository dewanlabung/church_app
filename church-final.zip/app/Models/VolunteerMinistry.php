<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class VolunteerMinistry extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['is_active' => 'boolean'];

    public function signups() { return $this->hasMany(VolunteerSignup::class); }
    public function scopeActive($q) { return $q->where('is_active', true); }
}
