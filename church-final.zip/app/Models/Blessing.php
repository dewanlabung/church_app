<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Blessing extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['is_active' => 'boolean', 'display_date' => 'date'];

    public function scopeActive($q) { return $q->where('is_active', true); }
    public function scopeToday($q) { return $q->where('display_date', today())->where('is_active', true); }
}
