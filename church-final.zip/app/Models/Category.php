<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Category extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['is_active' => 'boolean'];

    public function scopeActive($q) { return $q->where('is_active', true); }
    public function scopeType($q, $type) { return $q->where('type', $type); }

    protected static function booted()
    {
        static::creating(function ($c) {
            if (empty($c->slug)) $c->slug = Str::slug($c->name) . '-' . Str::random(3);
        });
    }
}
