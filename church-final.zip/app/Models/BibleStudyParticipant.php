<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class BibleStudyParticipant extends Model
{
    protected $guarded = ['id'];
    public function study() { return $this->belongsTo(BibleStudy::class, 'bible_study_id'); }
}
