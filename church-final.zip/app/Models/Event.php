<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Event extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['event_date' => 'date', 'end_date' => 'date', 'is_recurring' => 'boolean', 'is_featured' => 'boolean', 'is_active' => 'boolean'];

    public function category() { return $this->belongsTo(Category::class); }
    public function rsvps() { return $this->hasMany(EventRsvp::class); }
    public function scopeUpcoming($q) { return $q->where('event_date', '>=', today())->where('is_active', true)->orderBy('event_date'); }
    public function scopeActive($q) { return $q->where('is_active', true); }

    protected static function booted()
    {
        static::creating(function ($e) {
            if (empty($e->slug)) $e->slug = Str::slug($e->title) . '-' . Str::random(4);
        });
    }
}
