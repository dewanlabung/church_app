<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class DirectoryMember extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['birthday' => 'date', 'anniversary' => 'date', 'member_since' => 'date', 'is_active' => 'boolean', 'show_in_directory' => 'boolean'];

    public function category() { return $this->belongsTo(Category::class); }
    public function scopeVisible($q) { return $q->where('is_active', true)->where('show_in_directory', true); }
    public function getFullNameAttribute() { return $this->first_name . ' ' . $this->last_name; }
}
