<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Sermon extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['sermon_date' => 'date', 'is_featured' => 'boolean', 'is_active' => 'boolean'];

    public function category() { return $this->belongsTo(Category::class); }
    public function scopeActive($q) { return $q->where('is_active', true)->orderByDesc('sermon_date'); }

    protected static function booted()
    {
        static::creating(function ($s) {
            if (empty($s->slug)) $s->slug = Str::slug($s->title) . '-' . Str::random(4);
        });
    }
}
