<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class SeoMeta extends Model
{
    protected $table = 'seo_meta';
    protected $fillable = ['page_slug', 'title', 'description', 'keywords', 'og_image', 'canonical_url'];

    public static function forPage(string $slug): ?self
    {
        return static::where('page_slug', $slug)->first();
    }
}
