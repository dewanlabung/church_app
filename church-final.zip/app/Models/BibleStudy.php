<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class BibleStudy extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['is_active' => 'boolean'];

    public function category() { return $this->belongsTo(Category::class); }
    public function participants() { return $this->hasMany(BibleStudyParticipant::class); }
    public function scopeActive($q) { return $q->where('is_active', true)->whereIn('status', ['upcoming', 'active']); }

    protected static function booted()
    {
        static::creating(function ($s) {
            if (empty($s->slug)) $s->slug = Str::slug($s->title) . '-' . Str::random(4);
        });
    }
}
