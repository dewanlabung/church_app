<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class VolunteerSignup extends Model
{
    protected $guarded = ['id'];
    public function ministry() { return $this->belongsTo(VolunteerMinistry::class, 'volunteer_ministry_id'); }
}
