<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class PrayerRequest extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['is_anonymous' => 'boolean', 'is_approved' => 'boolean'];

    public function prays() { return $this->hasMany(PrayerPray::class); }
    public function scopeActive($q) { return $q->where('status', 'active')->where('is_approved', true); }
    public function scopePending($q) { return $q->where('is_approved', false); }
}
