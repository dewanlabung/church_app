<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;

class Announcement extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['start_date' => 'date', 'end_date' => 'date', 'is_active' => 'boolean'];

    public function scopeCurrent($q)
    {
        return $q->where('is_active', true)
            ->where(function ($q) { $q->whereNull('start_date')->orWhere('start_date', '<=', today()); })
            ->where(function ($q) { $q->whereNull('end_date')->orWhere('end_date', '>=', today()); });
    }
}
