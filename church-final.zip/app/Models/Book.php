<?php
namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Book extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['has_pdf' => 'boolean', 'is_featured' => 'boolean', 'is_active' => 'boolean'];

    public function category() { return $this->belongsTo(Category::class); }
    public function scopeActive($q) { return $q->where('is_active', true); }

    protected static function booted()
    {
        static::creating(function ($b) {
            if (empty($b->slug)) $b->slug = Str::slug($b->title) . '-' . Str::random(4);
        });
    }
}
