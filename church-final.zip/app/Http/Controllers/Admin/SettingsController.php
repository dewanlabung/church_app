<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Models\Category;
use App\Models\SeoMeta;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    public function getAll()
    {
        return response()->json(Setting::getAll());
    }

    public function update(Request $request)
    {
        foreach ($request->all() as $key => $value) {
            if ($key === '_token' || $key === '_method') continue;
            $group = 'general';
            if (in_array($key, ['facebook', 'youtube', 'instagram', 'twitter', 'tiktok'])) $group = 'social';
            if (in_array($key, ['address', 'phone', 'email', 'service_times'])) $group = 'contact';
            if (in_array($key, ['theme', 'primary_color', 'logo'])) $group = 'appearance';
            Setting::setVal($key, $value, $group);
        }
        return response()->json(['success' => true]);
    }

    public function categories()
    {
        return response()->json(Category::orderBy('type')->orderBy('sort_order')->get());
    }

    public function storeCategory(Request $request)
    {
        $cat = Category::create($request->except('_token'));
        return response()->json(['success' => true, 'id' => $cat->id]);
    }

    public function updateCategory($id, Request $request)
    {
        Category::findOrFail($id)->update($request->except(['_token', '_method']));
        return response()->json(['success' => true]);
    }

    public function deleteCategory($id)
    {
        Category::findOrFail($id)->delete();
        return response()->json(['success' => true]);
    }

    public function seo()
    {
        return response()->json(SeoMeta::all());
    }

    public function updateSeo($id, Request $request)
    {
        SeoMeta::findOrFail($id)->update($request->except(['_token', '_method']));
        return response()->json(['success' => true]);
    }
}
