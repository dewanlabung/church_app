<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ContentController extends Controller
{
    private function getModel(string $type)
    {
        return match($type) {
            'verses' => \App\Models\Verse::class,
            'blessings' => \App\Models\Blessing::class,
            'devotionals' => \App\Models\Devotional::class,
            'events' => \App\Models\Event::class,
            'books' => \App\Models\Book::class,
            'sermons' => \App\Models\Sermon::class,
            'studies' => \App\Models\BibleStudy::class,
            'prayers' => \App\Models\PrayerRequest::class,
            'reviews' => \App\Models\Review::class,
            'volunteers' => \App\Models\VolunteerMinistry::class,
            'announcements' => \App\Models\Announcement::class,
            'directory' => \App\Models\DirectoryMember::class,
            'messages' => \App\Models\ContactMessage::class,
            'donations' => \App\Models\Donation::class,
            default => null,
        };
    }

    public function index(string $type)
    {
        $class = $this->getModel($type);
        if (!$class) return response()->json(['error' => 'Invalid type'], 404);

        $query = $class::orderByDesc('id');

        if (request('search')) {
            $s = request('search');
            $query->where(function($q) use ($s) {
                foreach (['title','name','text','reference','first_name','last_name','request','speaker'] as $col) {
                    try { $q->orWhere($col, 'like', "%{$s}%"); } catch (\Exception $e) {}
                }
            });
        }

        return response()->json($query->paginate(request('per_page', 50)));
    }

    public function store(string $type, Request $request)
    {
        $class = $this->getModel($type);
        if (!$class) return response()->json(['error' => 'Invalid type'], 404);

        $data = $request->except(['_token', '_method', 'pdf_file', 'cover_image', 'image', 'photo']);

        // File uploads
        if ($request->hasFile('pdf_file')) {
            $path = $request->file('pdf_file')->store('books', 'public');
            $data['pdf_path'] = '/storage/' . $path;
            $data['has_pdf'] = true;
        }
        if ($request->hasFile('cover_image')) {
            $path = $request->file('cover_image')->store('covers', 'public');
            $data['cover_image'] = '/storage/' . $path;
        }
        if ($request->hasFile('image')) {
            $path = $request->file('image')->store('events', 'public');
            $data['image'] = '/storage/' . $path;
        }
        if ($request->hasFile('photo')) {
            $path = $request->file('photo')->store('photos', 'public');
            $data['photo'] = '/storage/' . $path;
        }
        if ($request->hasFile('thumbnail')) {
            $path = $request->file('thumbnail')->store('sermons', 'public');
            $data['thumbnail'] = '/storage/' . $path;
        }

        // Auto-slug
        if (isset($data['title']) && !isset($data['slug'])) {
            $data['slug'] = Str::slug($data['title']) . '-' . Str::random(4);
        }

        $item = $class::create($data);
        return response()->json(['message' => 'Created', 'item' => $item], 201);
    }

    public function update(string $type, int $id, Request $request)
    {
        $class = $this->getModel($type);
        if (!$class) return response()->json(['error' => 'Invalid type'], 404);

        $item = $class::findOrFail($id);
        $data = $request->except(['_token', '_method', 'pdf_file', 'cover_image', 'image', 'photo']);

        // Handle file uploads same as store
        if ($request->hasFile('pdf_file')) {
            $path = $request->file('pdf_file')->store('books', 'public');
            $data['pdf_path'] = '/storage/' . $path;
            $data['has_pdf'] = true;
        }
        if ($request->hasFile('cover_image')) {
            $path = $request->file('cover_image')->store('covers', 'public');
            $data['cover_image'] = '/storage/' . $path;
        }

        $item->update($data);
        return response()->json(['message' => 'Updated', 'item' => $item]);
    }

    public function destroy(string $type, int $id)
    {
        $class = $this->getModel($type);
        if (!$class) return response()->json(['error' => 'Invalid type'], 404);

        $class::findOrFail($id)->delete();
        return response()->json(['message' => 'Deleted']);
    }

    public function updatePrayerStatus(int $id, Request $request)
    {
        $prayer = \App\Models\PrayerRequest::findOrFail($id);
        $prayer->update(['status' => $request->status]);
        return response()->json(['message' => 'Updated']);
    }

    public function approveReview(int $id)
    {
        $review = \App\Models\Review::findOrFail($id);
        $review->update(['is_approved' => true]);
        return response()->json(['message' => 'Approved']);
    }
}
