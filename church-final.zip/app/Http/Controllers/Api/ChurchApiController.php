<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;


class ChurchApiController extends Controller
{
    public function info()
    {
        return response()->json(\App\Models\Setting::getAll());
    }

    public function verses()
    {
        return response()->json(\App\Models\Verse::active()->orderByDesc('display_date')->get());
    }

    public function verseToday()
    {
        return response()->json(\App\Models\Verse::today()->first() ?? \App\Models\Verse::active()->latest()->first());
    }

    public function blessings()
    {
        return response()->json(\App\Models\Blessing::active()->orderByDesc('display_date')->get());
    }

    public function blessingToday()
    {
        return response()->json(\App\Models\Blessing::today()->first() ?? \App\Models\Blessing::active()->latest()->first());
    }

    public function devotionals()
    {
        return response()->json(\App\Models\Devotional::active()->orderByDesc('display_date')->get());
    }

    public function devotionalToday()
    {
        return response()->json(\App\Models\Devotional::today()->first() ?? \App\Models\Devotional::active()->latest()->first());
    }

    public function prayers()
    {
        return response()->json(\App\Models\PrayerRequest::active()->orderByDesc('id')->get());
    }

    public function events()
    {
        return response()->json(\App\Models\Event::upcoming()->get());
    }

    public function books()
    {
        return response()->json(\App\Models\Book::active()->orderByDesc('id')->get());
    }

    public function studies()
    {
        return response()->json(\App\Models\BibleStudy::active()->get());
    }

    public function sermons()
    {
        return response()->json(\App\Models\Sermon::active()->get());
    }

    public function reviews()
    {
        $reviews = \App\Models\Review::approved()->orderByDesc('id')->get();
        return response()->json([
            'reviews' => $reviews,
            'average_rating' => round($reviews->avg('rating'), 1),
            'total_reviews' => $reviews->count(),
        ]);
    }

    public function volunteers()
    {
        return response()->json(\App\Models\VolunteerMinistry::active()->withCount('signups')->get());
    }

    public function announcements()
    {
        return response()->json(\App\Models\Announcement::current()->get());
    }

    public function directory()
    {
        return response()->json(\App\Models\DirectoryMember::visible()->orderBy('last_name')->get());
    }
}
