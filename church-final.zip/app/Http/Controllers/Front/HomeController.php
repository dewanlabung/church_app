<?php
namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Models\Verse;
use App\Models\Blessing;
use App\Models\Announcement;
use App\Models\Event;
use App\Models\Sermon;
use App\Models\Review;
use App\Models\SeoMeta;

class HomeController extends Controller
{
    public function index()
    {
        return view('front.pages.home', [
            'seo' => SeoMeta::forPage('home'),
            'verse' => Verse::today()->first() ?? Verse::active()->latest()->first(),
            'blessing' => Blessing::today()->first() ?? Blessing::active()->latest()->first(),
            'announcements' => Announcement::current()->latest()->take(3)->get(),
            'events' => Event::upcoming()->take(3)->get(),
            'sermons' => Sermon::active()->take(3)->get(),
            'reviews' => Review::approved()->latest()->take(3)->get(),
        ]);
    }
}
