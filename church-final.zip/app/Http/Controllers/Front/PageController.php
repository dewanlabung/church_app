<?php
namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\{Setting, Verse, Blessing, Devotional, PrayerRequest, PrayerPray, Event, EventRsvp, Book, BibleStudy, BibleStudyParticipant, Sermon, Review, VolunteerMinistry, VolunteerSignup, Announcement, DirectoryMember, ContactMessage, Donation, SeoMeta};

class PageController extends Controller
{
    public function about() { return view('front.pages.about', ['seo' => SeoMeta::forPage('about')]); }
    public function events() { return view('front.pages.events', ['events' => Event::upcoming()->get(), 'seo' => SeoMeta::forPage('events')]); }
    public function sermons() { return view('front.pages.sermons', ['sermons' => Sermon::active()->paginate(12), 'seo' => SeoMeta::forPage('sermons')]); }
    public function library() { return view('front.pages.library', ['books' => Book::active()->get(), 'seo' => SeoMeta::forPage('library')]); }
    public function prayers() { return view('front.pages.prayers', ['prayers' => PrayerRequest::active()->orderByDesc('created_at')->get(), 'seo' => SeoMeta::forPage('prayers')]); }
    public function studies() { return view('front.pages.studies', ['studies' => BibleStudy::active()->get(), 'seo' => SeoMeta::forPage('studies')]); }
    public function giving() { return view('front.pages.giving', ['seo' => SeoMeta::forPage('giving')]); }
    public function volunteer() { return view('front.pages.volunteer', ['ministries' => VolunteerMinistry::active()->withCount('signups')->get(), 'seo' => SeoMeta::forPage('volunteer')]); }
    public function reviews() { $r = Review::approved()->orderByDesc('id')->get(); return view('front.pages.reviews', ['reviews' => $r, 'avg' => round($r->avg('rating'),1), 'total' => $r->count(), 'seo' => SeoMeta::forPage('reviews')]); }
    public function directory() { return view('front.pages.directory', ['members' => DirectoryMember::visible()->orderBy('last_name')->get(), 'seo' => SeoMeta::forPage('directory')]); }
    public function contact() { return view('front.pages.contact', ['seo' => SeoMeta::forPage('contact')]); }

    // Form submissions
    public function submitPrayer(Request $request) {
        $request->validate(['request' => 'required|min:5']);
        PrayerRequest::create(['name' => $request->name ?: 'Anonymous', 'request' => $request->request, 'is_anonymous' => (bool)$request->is_anonymous, 'status' => Setting::val('prayer_auto_approve') ? 'active' : 'pending', 'is_approved' => (bool)Setting::val('prayer_auto_approve'), 'ip_address' => $request->ip()]);
        return back()->with('success', 'Prayer request submitted. Thank you for sharing.');
    }

    public function pray(int $id) {
        $p = PrayerRequest::findOrFail($id);
        PrayerPray::create(['prayer_request_id' => $id, 'ip_address' => request()->ip()]);
        $p->increment('prayer_count');
        return back()->with('success', 'Thank you for praying!');
    }

    public function submitReview(Request $request) {
        $request->validate(['name' => 'required', 'text' => 'required', 'rating' => 'required|integer|min:1|max:5']);
        Review::create(['name' => $request->name, 'text' => $request->text, 'rating' => $request->rating, 'is_approved' => (bool)Setting::val('review_auto_approve'), 'ip_address' => $request->ip()]);
        return back()->with('success', 'Thank you for your review!');
    }

    public function rsvp(int $id, Request $request) {
        $request->validate(['name' => 'required']);
        EventRsvp::create(['event_id' => $id, 'name' => $request->name, 'email' => $request->email, 'phone' => $request->phone, 'guests' => $request->guests ?? 1]);
        return back()->with('success', 'RSVP confirmed!');
    }

    public function joinStudy(int $id, Request $request) {
        $request->validate(['name' => 'required']);
        BibleStudyParticipant::create(['bible_study_id' => $id, 'name' => $request->name, 'email' => $request->email, 'phone' => $request->phone]);
        $study = BibleStudy::find($id);
        if ($study) $study->increment('participant_count');
        return back()->with('success', 'Welcome to the study!');
    }

    public function volunteerSignup(int $id, Request $request) {
        $request->validate(['name' => 'required']);
        VolunteerSignup::create(['volunteer_ministry_id' => $id, 'name' => $request->name, 'email' => $request->email, 'phone' => $request->phone, 'message' => $request->message]);
        return back()->with('success', 'Thank you for volunteering!');
    }

    public function submitDonation(Request $request) {
        $request->validate(['amount' => 'required|numeric|min:1']);
        Donation::create(['amount' => $request->amount, 'donor_name' => $request->donor_name, 'donor_email' => $request->donor_email, 'frequency' => $request->frequency ?? 'one-time', 'payment_method' => $request->payment_method ?? 'online', 'status' => 'pending']);
        return back()->with('success', 'Thank you for your generous gift!');
    }

    public function submitContact(Request $request) {
        $request->validate(['name' => 'required', 'email' => 'required|email', 'message' => 'required']);
        ContactMessage::create($request->only(['name','email','phone','subject','message']));
        return back()->with('success', 'Message sent! We\'ll be in touch.');
    }

    public function downloadBook(int $id) {
        $book = Book::findOrFail($id);
        if (!$book->has_pdf || !$book->pdf_path) abort(404);
        $book->increment('download_count');
        return redirect($book->pdf_path);
    }
}
