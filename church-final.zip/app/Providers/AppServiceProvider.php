<?php
namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Schema;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void {}

    public function boot(): void
    {
        try {
            if (Schema::hasTable('church_settings')) {
                $settings = \App\Models\Setting::getAll();
                View::share('churchSettings', $settings);
            } else {
                View::share('churchSettings', []);
            }
        } catch (\Exception $e) {
            View::share('churchSettings', []);
        }
    }
}
