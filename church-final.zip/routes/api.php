<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ChurchApiController;

Route::prefix('church')->group(function () {
    Route::get('/info', [ChurchApiController::class, 'info']);
    Route::get('/verses', [ChurchApiController::class, 'verses']);
    Route::get('/verses/today', [ChurchApiController::class, 'verseToday']);
    Route::get('/blessings', [ChurchApiController::class, 'blessings']);
    Route::get('/blessings/today', [ChurchApiController::class, 'blessingToday']);
    Route::get('/devotionals', [ChurchApiController::class, 'devotionals']);
    Route::get('/devotionals/today', [ChurchApiController::class, 'devotionalToday']);
    Route::get('/prayers', [ChurchApiController::class, 'prayers']);
    Route::get('/events', [ChurchApiController::class, 'events']);
    Route::get('/books', [ChurchApiController::class, 'books']);
    Route::get('/studies', [ChurchApiController::class, 'studies']);
    Route::get('/sermons', [ChurchApiController::class, 'sermons']);
    Route::get('/reviews', [ChurchApiController::class, 'reviews']);
    Route::get('/volunteers', [ChurchApiController::class, 'volunteers']);
    Route::get('/announcements', [ChurchApiController::class, 'announcements']);
    Route::get('/directory', [ChurchApiController::class, 'directory']);
});
