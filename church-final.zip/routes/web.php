<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Front\HomeController;
use App\Http\Controllers\Front\PageController;
use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\ContentController;
use App\Http\Controllers\Admin\SettingsController;

// ─── PUBLIC ──────────────────────────────────────────────
Route::get('/', [HomeController::class, 'index']);
Route::get('/events', [PageController::class, 'events']);
Route::get('/sermons', [PageController::class, 'sermons']);
Route::get('/library', [PageController::class, 'library']);
Route::get('/prayers', [PageController::class, 'prayers']);
Route::get('/studies', [PageController::class, 'studies']);
Route::get('/giving', [PageController::class, 'giving']);
Route::get('/volunteer', [PageController::class, 'volunteer']);
Route::get('/reviews', [PageController::class, 'reviews']);
Route::get('/directory', [PageController::class, 'directory']);
Route::get('/about', [PageController::class, 'about']);
Route::get('/contact', [PageController::class, 'contact']);

Route::post('/prayers', [PageController::class, 'submitPrayer']);
Route::post('/prayers/{id}/pray', [PageController::class, 'pray']);
Route::post('/reviews', [PageController::class, 'submitReview']);
Route::post('/events/{id}/rsvp', [PageController::class, 'rsvp']);
Route::post('/studies/{id}/join', [PageController::class, 'joinStudy']);
Route::post('/volunteer/{id}/signup', [PageController::class, 'volunteerSignup']);
Route::post('/giving', [PageController::class, 'submitDonation']);
Route::post('/contact', [PageController::class, 'submitContact']);
Route::get('/books/{id}/download', [PageController::class, 'downloadBook']);

// ─── ADMIN AUTH ──────────────────────────────────────────
Route::get('/admin/login', [AuthController::class, 'showLogin']);
Route::post('/admin/login', [AuthController::class, 'login']);
Route::post('/admin/logout', [AuthController::class, 'logout']);

// ─── ADMIN PANEL ─────────────────────────────────────────
Route::prefix('admin')->middleware('admin')->group(function () {
    Route::get('/', [DashboardController::class, 'index']);
    Route::get('/api/{type}', [ContentController::class, 'index']);
    Route::post('/api/{type}', [ContentController::class, 'store']);
    Route::put('/api/{type}/{id}', [ContentController::class, 'update']);
    Route::delete('/api/{type}/{id}', [ContentController::class, 'destroy']);
    Route::put('/api/prayers/{id}/status', [ContentController::class, 'updatePrayerStatus']);
    Route::put('/api/reviews/{id}/approve', [ContentController::class, 'approveReview']);
    Route::get('/api/settings/all', [SettingsController::class, 'getAll']);
    Route::put('/api/settings', [SettingsController::class, 'update']);
    Route::get('/api/categories', [SettingsController::class, 'categories']);
    Route::post('/api/categories', [SettingsController::class, 'storeCategory']);
    Route::put('/api/categories/{id}', [SettingsController::class, 'updateCategory']);
    Route::delete('/api/categories/{id}', [SettingsController::class, 'deleteCategory']);
    Route::get('/api/seo', [SettingsController::class, 'seo']);
    Route::put('/api/seo/{id}', [SettingsController::class, 'updateSeo']);
});
