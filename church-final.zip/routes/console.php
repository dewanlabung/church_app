<?php
// Console routes
