const AP='/admin/api';let P='dashboard';
const N=[{s:'Content'},{id:'dashboard',i:'📊',l:'Dashboard'},{id:'verses',i:'📖',l:'Verses'},{id:'blessings',i:'✨',l:'Blessings'},{id:'devotionals',i:'🕊️',l:'Devotionals'},{id:'announcements',i:'📢',l:'Announcements'},{s:'Ministry'},{id:'events',i:'📅',l:'Events'},{id:'sermons',i:'🎙️',l:'Sermons'},{id:'studies',i:'📖',l:'Studies'},{id:'books',i:'📚',l:'Library'},{id:'volunteers',i:'🤝',l:'Volunteers'},{s:'Community'},{id:'prayers',i:'🙏',l:'Prayers'},{id:'reviews',i:'⭐',l:'Reviews'},{id:'directory',i:'👥',l:'Directory'},{id:'donations',i:'💛',l:'Donations'},{id:'messages',i:'📩',l:'Messages'},{s:'Settings'},{id:'categories',i:'🏷️',l:'Categories'},{id:'churchinfo',i:'⛪',l:'Church Info'},{id:'seo',i:'🔍',l:'SEO'}];
function E(s){if(!s)return'';const d=document.createElement('div');d.textContent=s;return d.innerHTML}
function F(d){return d?new Date(d).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'}):'—'}
function T(){return new Date().toISOString().split('T')[0]}
function $(i){return document.getElementById(i)}function V(i){return $(i)?.value?.trim()||''}
function toast(m,e){const t=$('to');t.textContent=m;t.className='to sh'+(e?' er':'');t.style.animation='none';t.offsetHeight;t.style.animation='ti .3s';setTimeout(()=>t.classList.remove('sh'),3e3)}

async function api(path,o={}){
  const h={'Accept':'application/json','X-CSRF-TOKEN':CSRF,'X-Requested-With':'XMLHttpRequest'};
  if(!(o.body instanceof FormData))h['Content-Type']='application/json';
  try{const r=await fetch(AP+path,{headers:h,...o});if(!r.ok)throw new Error(await r.text());return await r.json()}catch(e){toast('Error: '+e.message,1);return null}}

function thm(){const h=document.documentElement;const d=h.dataset.theme==='dark';h.dataset.theme=d?'light':'dark';$('ti').textContent=d?'☀️':'🌙';localStorage.setItem('ct',h.dataset.theme)}
(function(){const t=localStorage.getItem('ct');if(t)document.documentElement.dataset.theme=t})();

function bn(){$('nv').innerHTML=N.map(n=>n.s?`<div class="sb-sc">${n.s}</div>`:`<button class="ni ${n.id===P?'ac':''}" onclick="go('${n.id}')"><span class="ic">${n.i}</span>${n.l}</button>`).join('')}
function tg(){$('sb').classList.toggle('op');$('ov').classList.toggle('op')}
function go(p){P=p;$('pt').textContent=(N.find(n=>n.id===p)||{}).l||'Dashboard';bn();$('sb').classList.remove('op');$('ov').classList.remove('op');rn()}
function om(t,h){$('mt').textContent=t;$('mb').innerHTML=h;$('md').classList.add('op')}
function cm(){$('md').classList.remove('op')}

function ff(t,id,lb,o={}){const v=o.value||'',ph=o.placeholder||'';
if(t==='textarea')return`<div class="fg"><label>${lb}</label><textarea class="ft" id="${id}" placeholder="${ph}">${E(v)}</textarea></div>`;
if(t==='select'){const ops=(o.options||[]).map(x=>`<option value="${x.v}" ${x.v==v?'selected':''}>${E(x.l)}</option>`).join('');return`<div class="fg"><label>${lb}</label><select class="fs" id="${id}">${ops}</select></div>`}
if(t==='file')return`<div class="fg"><label>${lb}</label><input type="file" class="fi" id="${id}" accept="${o.accept||'*'}"></div>`;
return`<div class="fg"><label>${lb}</label><input type="${t}" class="fi" id="${id}" value="${E(v)}" placeholder="${ph}"></div>`}

function rl(items,tf,mf,af){if(!items?.length)return'<div class="em">No items yet</div>';return items.map(i=>`<div class="it"><div class="it-i"><div class="it-t">${tf(i)}</div><div class="it-m">${mf(i)}</div></div><div class="it-a">${af(i)}</div></div>`).join('')}

const R={};

R.dashboard=async c=>{
  const types=['verses','blessings','prayers','events','books','studies','sermons','devotionals','volunteers','reviews','announcements','directory','messages'];
  const results=await Promise.allSettled(types.map(t=>api('/'+t)));
  const counts=types.map((t,i)=>{const v=results[i].status==='fulfilled'?results[i].value:null;return{l:t.charAt(0).toUpperCase()+t.slice(1),n:v?.total||v?.data?.length||(Array.isArray(v)?v.length:0)}});
  c.innerHTML=`<div class="sts">${counts.map(s=>`<div class="st"><div class="st-n">${s.n}</div><div class="st-l">${s.l}</div></div>`).join('')}</div>
  <div class="cd"><div class="cd-h"><span class="cd-t">Quick Actions</span></div><div class="cd-b"><div style="display:flex;gap:8px;flex-wrap:wrap">
  <button class="bt bg" onclick="go('verses')">📖 Verses</button><button class="bt bg" onclick="go('events')">📅 Events</button><button class="bt bg" onclick="go('sermons')">🎙️ Sermons</button>
  <button class="bt bo" onclick="go('churchinfo')">⛪ Church Info</button><button class="bt bo" onclick="go('categories')">🏷️ Categories</button><button class="bt bo" onclick="go('seo')">🔍 SEO</button></div></div></div>`};

// Generic CRUD builder
function crud(type,label,icon,fields,titleFn,metaFn,extra={}){
  R[type]=async c=>{
    const d=await api('/'+type);const items=d?.data||d||[];
    let bulk='';
    if(extra.bulk){bulk=`<div class="cd"><div class="cd-h"><span class="cd-t">📥 Bulk Import</span></div><div class="cd-b">
      <textarea class="ft" id="bulk-${type}" placeholder="${extra.bulkPh||'Paste data...'}" style="font-size:.82rem"></textarea>
      <button class="bt bo" style="margin-top:8px" onclick="bulkImport('${type}')">📥 Import</button></div></div>`}
    c.innerHTML=`<div class="cd"><div class="cd-h"><span class="cd-t">➕ Add ${label}</span></div><div class="cd-b">
      ${fields()}
      <button class="bt bg bk" onclick="addItem('${type}')">➕ Add</button></div></div>${bulk}
      <div class="cd"><div class="cd-h"><span class="cd-t">${icon} All ${label}s (${items.length})</span></div><div class="cd-b">
      ${rl(items,titleFn,metaFn,i=>`<button class="bt bo bs" onclick="editItem('${type}',${i.id})">✏️</button><button class="bt bd bs" onclick="delItem('${type}',${i.id})">🗑️</button>`)}</div></div>`;
    document.querySelectorAll('input[type=date]').forEach(i=>{if(!i.value)i.value=T()});
  };
}

crud('verses','Verse','📖',
  ()=>`${ff('textarea','f-text','Verse Text',{placeholder:'Enter verse...'})}
    <div class="fg2">${ff('text','f-reference','Reference',{placeholder:'John 3:16'})}${ff('date','f-display_date','Date')}</div>`,
  i=>E(i.reference),i=>E(i.text).substring(0,80)+'... — '+F(i.display_date),
  {bulk:true,bulkPh:'Reference | Text (one per line)\nJohn 3:16 | For God so loved...'});

crud('blessings','Blessing','✨',
  ()=>`<div class="fg2">${ff('text','f-title','Title',{placeholder:"Today's Blessing"})}${ff('text','f-author','Author',{placeholder:'Numbers 6:24'})}</div>
    ${ff('textarea','f-text','Text',{placeholder:'Blessing text...'})}${ff('date','f-display_date','Date')}`,
  i=>E(i.title),i=>E(i.text).substring(0,80)+'... — '+F(i.display_date));

crud('devotionals','Devotional','🕊️',
  ()=>`<div class="fg2">${ff('text','f-title','Title',{placeholder:'Morning Light'})}${ff('text','f-verse','Verse Ref',{placeholder:'Psalm 46:10'})}</div>
    ${ff('textarea','f-content','Content',{placeholder:'Devotional...'})}
    <div class="fg2">${ff('text','f-author','Author',{placeholder:'Pastor'})}${ff('date','f-display_date','Date')}</div>`,
  i=>E(i.title),i=>`${E(i.verse)} • ${E(i.author)} • ${F(i.display_date)}`);

crud('events','Event','📅',
  ()=>`<div class="fg2">${ff('text','f-title','Title',{placeholder:'Event name'})}${ff('text','f-category','Category',{placeholder:'Worship'})}</div>
    ${ff('textarea','f-description','Description',{placeholder:'Description...'})}
    <div class="fg3">${ff('date','f-event_date','Date')}${ff('time','f-event_time','Time')}${ff('text','f-location','Location',{placeholder:'Sanctuary'})}</div>`,
  i=>E(i.title),i=>`📅 ${F(i.event_date)} ${i.event_time?'• '+i.event_time.slice(0,5):''} ${i.location?'• '+E(i.location):''}`);

crud('sermons','Sermon','🎙️',
  ()=>`<div class="fg2">${ff('text','f-title','Title',{placeholder:'Sermon title'})}${ff('text','f-speaker','Speaker',{placeholder:'Speaker'})}</div>
    ${ff('textarea','f-description','Description',{placeholder:'Description...'})}
    <div class="fg3">${ff('date','f-sermon_date','Date')}${ff('text','f-duration','Duration',{placeholder:'42 min'})}${ff('text','f-series','Series',{placeholder:'Series'})}</div>
    <div class="fg2">${ff('text','f-audio_url','Audio URL',{placeholder:'https://...'})}${ff('text','f-video_url','Video URL',{placeholder:'https://...'})}</div>`,
  i=>E(i.title),i=>`${E(i.speaker)} • ${F(i.sermon_date)} ${i.duration?'• '+i.duration:''}`);

crud('books','Book','📚',
  ()=>`<div class="fg2">${ff('text','f-title','Title',{placeholder:'Book title'})}${ff('text','f-author','Author',{placeholder:'Author'})}</div>
    <div class="fg2">${ff('text','f-category','Category',{placeholder:'Theology'})}${ff('number','f-pages','Pages',{placeholder:'0'})}</div>
    ${ff('textarea','f-description','Description',{placeholder:'About...'})}<div class="fg"><label>PDF</label><input type="file" class="fi" id="f-pdf_file" accept=".pdf"></div>`,
  i=>E(i.title)+' <span style="color:var(--tx3)">by '+E(i.author)+'</span>',i=>`${i.pages||0}p ${i.has_pdf?'• 📥':''}`);

crud('studies','Study','📖',
  ()=>`<div class="fg2">${ff('text','f-title','Title',{placeholder:'Study name'})}${ff('text','f-leader','Leader',{placeholder:'Leader'})}</div>
    ${ff('textarea','f-description','Description',{placeholder:'Description...'})}
    <div class="fg2">${ff('text','f-category','Category',{placeholder:'Gospel'})}${ff('number','f-total_weeks','Weeks',{placeholder:'8'})}</div>`,
  i=>E(i.title),i=>`${E(i.leader)} • Wk ${i.current_week||1}/${i.total_weeks} • ${i.status}`);

crud('volunteers','Ministry','🤝',
  ()=>`<div class="fg2">${ff('text','f-name','Name',{placeholder:'Ministry name'})}${ff('text','f-icon','Icon',{placeholder:'🤝'})}</div>
    ${ff('textarea','f-description','Description',{placeholder:'Description...'})}${ff('number','f-spots_available','Spots',{placeholder:'(unlimited)'})}`,
  i=>`${i.icon||'🤝'} ${E(i.name)}`,i=>`${i.spots_available||'∞'} spots`);

crud('announcements','Announcement','📢',
  ()=>`<div class="fg2">${ff('text','f-title','Title',{placeholder:'Announcement'})}${ff('select','f-priority','Priority',{options:[{v:'normal',l:'Normal'},{v:'important',l:'⭐ Important'},{v:'urgent',l:'🚨 Urgent'}]})}</div>
    ${ff('textarea','f-content','Content',{placeholder:'Content...'})}
    <div class="fg2">${ff('date','f-start_date','Start')}${ff('date','f-end_date','End')}</div>`,
  i=>`${i.priority==='urgent'?'🚨':'📢'} ${E(i.title)}`,i=>E(i.content).substring(0,80)+'...');

crud('directory','Member','👥',
  ()=>`<div class="fg3">${ff('text','f-first_name','First Name',{placeholder:'First'})}${ff('text','f-last_name','Last Name',{placeholder:'Last'})}${ff('text','f-role','Role',{placeholder:'member'})}</div>
    <div class="fg2">${ff('text','f-email','Email',{placeholder:'email@'})}${ff('text','f-phone','Phone',{placeholder:'(555)...'})}</div>
    ${ff('text','f-address','Address',{placeholder:'Address'})}`,
  i=>`${E(i.first_name)} ${E(i.last_name)}`,i=>`${E(i.role||'member')} • ${E(i.email||'')}`);

// Prayers (special - moderation)
R.prayers=async c=>{const d=await api('/prayers');const items=d?.data||d||[];
c.innerHTML=`<div class="cd"><div class="cd-h"><span class="cd-t">🙏 Prayers (${items.length})</span></div><div class="cd-b">
${rl(items,i=>E(i.name)+' <span style="color:var(--g)">🙏 '+i.prayer_count+'</span>',i=>E(i.request).substring(0,100)+'... • '+i.status,
i=>`<button class="bt bo bs" onclick="prayerSt(${i.id},'answered')">✓</button><button class="bt bo bs" onclick="prayerSt(${i.id},'active')">👁</button><button class="bt bd bs" onclick="prayerSt(${i.id},'archived')">🗑</button>`)}</div></div>`};
window.prayerSt=async(id,s)=>{await api('/prayers/'+id+'/status',{method:'PUT',body:JSON.stringify({status:s})});toast('✅ Updated!');rn()};

// Reviews (moderation)
R.reviews=async c=>{const d=await api('/reviews');const items=d?.data||d||[];
c.innerHTML=`<div class="cd"><div class="cd-h"><span class="cd-t">⭐ Reviews (${items.length})</span></div><div class="cd-b">
${rl(items,i=>'<span style="color:var(--g)">'+'★'.repeat(i.rating)+'☆'.repeat(5-i.rating)+'</span> '+E(i.name)+(!i.is_approved?' <span style="color:var(--rd)">[pending]</span>':''),
i=>'"'+E(i.text).substring(0,100)+'..."',
i=>(!i.is_approved?`<button class="bt bo bs" onclick="approveRev(${i.id})">✓ Approve</button>`:'')+`<button class="bt bd bs" onclick="delItem('reviews',${i.id})">🗑</button>`)}</div></div>`};
window.approveRev=async id=>{await api('/reviews/'+id+'/approve',{method:'PUT'});toast('✅ Approved!');rn()};

// Donations & Messages
R.donations=async c=>{const d=await api('/donations');const items=d?.data||d||[];
c.innerHTML=`<div class="cd"><div class="cd-h"><span class="cd-t">💛 Donations (${items.length})</span></div><div class="cd-b">
${rl(items,i=>'$'+parseFloat(i.amount).toFixed(2)+' — '+(E(i.donor_name)||'Anonymous'),i=>`${i.frequency} • ${i.status} • ${F(i.created_at)}`,i=>'')}</div></div>`};

R.messages=async c=>{const d=await api('/messages');const items=d?.data||d||[];
c.innerHTML=`<div class="cd"><div class="cd-h"><span class="cd-t">📩 Messages (${items.length})</span></div><div class="cd-b">
${rl(items,i=>`${i.is_read?'':'🔵 '}${E(i.name)} — ${E(i.subject||'No subject')}`,i=>`${E(i.email)} • ${F(i.created_at)}`,
i=>`<button class="bt bo bs" onclick="readMsg(${i.id})">Read</button><button class="bt bd bs" onclick="delItem('messages',${i.id})">🗑</button>`)}</div></div>`};
window.readMsg=async id=>{const d=await api('/messages');const items=d?.data||d||[];const m=items.find(x=>x.id===id);if(!m)return;
om('Message from '+E(m.name),`<p><b>From:</b> ${E(m.name)} (${E(m.email)})</p><p><b>Phone:</b> ${E(m.phone||'—')}</p><p><b>Subject:</b> ${E(m.subject||'—')}</p><hr style="border-color:var(--b);margin:12px 0"><p>${E(m.message)}</p>`)};

// Categories
R.categories=async c=>{const d=await api('/categories-list');const items=d||[];const types=['event','book','study','sermon','directory'];
c.innerHTML=`<div class="cd"><div class="cd-h"><span class="cd-t">➕ Add Category</span></div><div class="cd-b">
<div class="fg3">${ff('text','f-name','Name',{placeholder:'Category name'})}${ff('select','f-type','Type',{options:types.map(t=>({v:t,l:t.charAt(0).toUpperCase()+t.slice(1)}))})}${ff('text','f-icon','Icon',{placeholder:'📁'})}</div>
<div class="fg2">${ff('text','f-color','Color',{placeholder:'#C9A84C'})}${ff('number','f-sort_order','Sort Order',{placeholder:'0'})}</div>
${ff('textarea','f-description','Description',{placeholder:'Optional...'})}
<button class="bt bg bk" onclick="addCat()">➕ Add Category</button></div></div>
<div class="cd"><div class="cd-h"><span class="cd-t">🏷️ All Categories (${items.length})</span></div><div class="cd-b">
${rl(items,i=>`${i.icon||'📁'} ${E(i.name)} <span style="color:var(--tx3)">[${i.type}]</span>`,i=>`${E(i.description||'')} • sort: ${i.sort_order}`,
i=>`<button class="bt bd bs" onclick="delCat(${i.id})">🗑</button>`)}</div></div>`};
window.addCat=async()=>{await api('/categories-list',{method:'POST',body:JSON.stringify({name:V('f-name'),type:V('f-type'),icon:V('f-icon')||'📁',color:V('f-color')||'#C9A84C',sort_order:parseInt(V('f-sort_order'))||0,description:V('f-description')})});toast('✅ Added!');rn()};
window.delCat=async id=>{if(!confirm('Delete?'))return;await api('/categories-list/'+id,{method:'DELETE'});toast('🗑 Deleted!');rn()};

// SEO
R.seo=async c=>{const d=await api('/seo-list');const items=d||[];
c.innerHTML=`<div class="cd"><div class="cd-h"><span class="cd-t">➕ Add SEO Page</span></div><div class="cd-b">
<div class="fg2">${ff('text','f-page_slug','Page Slug',{placeholder:'about'})}${ff('text','f-title','Title',{placeholder:'About Our Church'})}</div>
${ff('textarea','f-description','Description',{placeholder:'Meta description...'})}
${ff('text','f-keywords','Keywords',{placeholder:'church, worship, community'})}
<button class="bt bg bk" onclick="addSeo()">➕ Add</button></div></div>
<div class="cd"><div class="cd-h"><span class="cd-t">🔍 SEO Pages (${items.length})</span></div><div class="cd-b">
${rl(items,i=>`/${E(i.page_slug)}`,i=>`${E(i.title||'—')} • ${E(i.description||'').substring(0,60)}...`,
i=>`<button class="bt bo bs" onclick="editSeo(${i.id})">✏️</button>`)}</div></div>`};
window.addSeo=async()=>{await api('/seo-list',{method:'POST',body:JSON.stringify({page_slug:V('f-page_slug'),title:V('f-title'),description:V('f-description'),keywords:V('f-keywords')})});toast('✅ Added!');rn()};
window.editSeo=async id=>{const d=await api('/seo-list');const items=d||[];const s=items.find(x=>x.id===id);if(!s)return;
om('Edit SEO: /'+s.page_slug,`${ff('text','se-title','Title',{value:s.title})}${ff('textarea','se-description','Description',{value:s.description})}${ff('text','se-keywords','Keywords',{value:s.keywords})}
<button class="bt bg bk" onclick="saveSeo(${id})">💾 Save</button>`);};
window.saveSeo=async id=>{await api('/seo-list/'+id,{method:'PUT',body:JSON.stringify({title:V('se-title'),description:V('se-description'),keywords:V('se-keywords')})});toast('✅ Saved!');cm();rn()};

// Church Info
R.churchinfo=async c=>{const info=await api('/settings/all')||{};
c.innerHTML=`<div class="cd"><div class="cd-h"><span class="cd-t">⛪ Church Information</span></div><div class="cd-b">
<div class="fg2">${ff('text','s-church_name','Church Name',{value:info.church_name})}${ff('text','s-tagline','Tagline',{value:info.tagline})}</div>
${ff('text','s-address','Address',{value:info.address})}
<div class="fg2">${ff('text','s-phone','Phone',{value:info.phone})}${ff('text','s-email','Email',{value:info.email})}</div>
<div class="fg2">${ff('text','s-pastor','Pastor',{value:info.pastor})}${ff('text','s-denomination','Denomination',{value:info.denomination})}</div>
${ff('textarea','s-mission','Mission',{value:info.mission})}${ff('textarea','s-about_text','About Text',{value:info.about_text})}${ff('textarea','s-vision','Vision',{value:info.vision})}
<h3 style="margin:16px 0 10px;font-size:.85rem;color:var(--g)">🌐 Social</h3>
<div class="fg2">${ff('text','s-facebook','Facebook',{value:info.facebook})}${ff('text','s-youtube','YouTube',{value:info.youtube})}</div>
<div class="fg2">${ff('text','s-instagram','Instagram',{value:info.instagram})}${ff('text','s-twitter','Twitter',{value:info.twitter})}</div>
<h3 style="margin:16px 0 10px;font-size:.85rem;color:var(--g)">⚙️ Features</h3>
<div class="ck"><input type="checkbox" id="s-prayer_auto_approve" ${info.prayer_auto_approve==='1'?'checked':''}><label for="s-prayer_auto_approve">Auto-approve prayer requests</label></div>
<div class="ck"><input type="checkbox" id="s-review_auto_approve" ${info.review_auto_approve==='1'?'checked':''}><label for="s-review_auto_approve">Auto-approve reviews</label></div>
<button class="bt bg bk" style="margin-top:12px" onclick="saveSettings()">💾 Save All</button></div></div>`};
window.saveSettings=async()=>{const keys=['church_name','tagline','address','phone','email','pastor','denomination','mission','about_text','vision','facebook','youtube','instagram','twitter'];
const data={};keys.forEach(k=>data[k]=V('s-'+k));
data.prayer_auto_approve=$('s-prayer_auto_approve')?.checked?'1':'0';
data.review_auto_approve=$('s-review_auto_approve')?.checked?'1':'0';
await api('/settings',{method:'PUT',body:JSON.stringify(data)});toast('✅ Saved!')};

// Generic add/edit/delete
window.addItem=async type=>{const fields=document.querySelectorAll('[id^="f-"]');const data={};const fd=new FormData();let hasFile=false;
fields.forEach(f=>{const k=f.id.replace('f-','');if(f.type==='file'){if(f.files[0]){fd.append(k,f.files[0]);hasFile=true}}else if(f.type==='checkbox'){data[k]=f.checked}else{data[k]=f.value.trim()}});
if(hasFile){Object.keys(data).forEach(k=>fd.append(k,data[k]));await fetch(AP+'/'+type,{method:'POST',headers:{'Accept':'application/json','X-CSRF-TOKEN':CSRF},body:fd}).then(r=>r.json())}
else{await api('/'+type,{method:'POST',body:JSON.stringify(data)})}
toast('✅ Added!');rn()};

window.editItem=async(type,id)=>{const d=await api('/'+type);const items=d?.data||d||[];const i=items.find(x=>x.id===id);if(!i)return;
let fields='';Object.keys(i).forEach(k=>{if(['id','created_at','updated_at','slug','ip_address','download_count','view_count','prayer_count','participant_count','signups_count'].includes(k))return;
const v=i[k];if(typeof v==='boolean')fields+=`<div class="ck"><input type="checkbox" id="e-${k}" ${v?'checked':''}><label for="e-${k}">${k.replace(/_/g,' ')}</label></div>`;
else if(String(v||'').length>100)fields+=ff('textarea','e-'+k,k.replace(/_/g,' '),{value:v});
else fields+=ff('text','e-'+k,k.replace(/_/g,' '),{value:v||''});});
om('Edit #'+id,fields+`<button class="bt bg bk" onclick="saveItem('${type}',${id})">💾 Save</button>`);};

window.saveItem=async(type,id)=>{const fields=document.querySelectorAll('[id^="e-"]');const data={};
fields.forEach(f=>{const k=f.id.replace('e-','');data[k]=f.type==='checkbox'?f.checked:f.value.trim()});
await api('/'+type+'/'+id,{method:'PUT',body:JSON.stringify(data)});toast('✅ Saved!');cm();rn()};

window.delItem=async(type,id)=>{if(!confirm('Delete?'))return;await api('/'+type+'/'+id,{method:'DELETE'});toast('🗑 Deleted!');rn()};

// Bulk import
window.bulkImport=async type=>{const text=V('bulk-'+type);if(!text){toast('Nothing to import',1);return}
const lines=text.split('\n').filter(l=>l.trim());let c=0;
for(const l of lines){const p=l.split('|').map(s=>s.trim());
if(type==='verses'&&p.length>=2){await api('/'+type,{method:'POST',body:JSON.stringify({reference:p[0],text:p[1],display_date:p[2]||T()})});c++}}
toast(`✅ Imported ${c} items!`);rn()};

async function rn(){const c=$('ct');c.innerHTML='<div style="text-align:center;padding:50px;color:var(--tx3)">Loading...</div>';const fn=R[P];if(fn)await fn(c);else c.innerHTML='<div class="em">Coming soon</div>'}

bn();rn();
