<?php
/**
 * ✝ Church Platform - Web GUI Installer
 * 
 * Upload this file to your Laravel root and visit it in a browser.
 * It will configure the database, run migrations, seed data,
 * register middleware, and set up everything automatically.
 * 
 * After installation, this file self-deletes for security.
 */

// Prevent timeout
set_time_limit(300);
error_reporting(E_ALL);

$basePath = dirname(__FILE__);
$step = $_POST['step'] ?? ($_GET['step'] ?? 'welcome');
$errors = [];
$success = [];

// ─── Helper Functions ────────────────────────────────────

function checkRequirements($basePath) {
    $checks = [];
    $checks['php_version'] = ['label' => 'PHP 8.1+', 'ok' => version_compare(PHP_VERSION, '8.1.0', '>='), 'value' => PHP_VERSION];
    $checks['pdo_mysql'] = ['label' => 'PDO MySQL', 'ok' => extension_loaded('pdo_mysql'), 'value' => extension_loaded('pdo_mysql') ? 'Installed' : 'Missing'];
    $checks['mbstring'] = ['label' => 'Mbstring', 'ok' => extension_loaded('mbstring'), 'value' => extension_loaded('mbstring') ? 'Installed' : 'Missing'];
    $checks['openssl'] = ['label' => 'OpenSSL', 'ok' => extension_loaded('openssl'), 'value' => extension_loaded('openssl') ? 'Installed' : 'Missing'];
    $checks['tokenizer'] = ['label' => 'Tokenizer', 'ok' => extension_loaded('tokenizer'), 'value' => extension_loaded('tokenizer') ? 'Installed' : 'Missing'];
    $checks['json'] = ['label' => 'JSON', 'ok' => extension_loaded('json'), 'value' => extension_loaded('json') ? 'Installed' : 'Missing'];
    $checks['fileinfo'] = ['label' => 'Fileinfo', 'ok' => extension_loaded('fileinfo'), 'value' => extension_loaded('fileinfo') ? 'Installed' : 'Missing'];
    $checks['artisan'] = ['label' => 'Laravel Artisan', 'ok' => file_exists($basePath . '/artisan'), 'value' => file_exists($basePath . '/artisan') ? 'Found' : 'Missing - run composer create-project first'];
    $checks['vendor'] = ['label' => 'Vendor Directory', 'ok' => is_dir($basePath . '/vendor'), 'value' => is_dir($basePath . '/vendor') ? 'Found' : 'Missing - run composer install first'];
    $checks['storage_writable'] = ['label' => 'Storage Writable', 'ok' => is_writable($basePath . '/storage'), 'value' => is_writable($basePath . '/storage') ? 'Writable' : 'Not Writable'];
    $checks['cache_writable'] = ['label' => 'Bootstrap/Cache Writable', 'ok' => is_writable($basePath . '/bootstrap/cache'), 'value' => is_writable($basePath . '/bootstrap/cache') ? 'Writable' : 'Not Writable'];
    return $checks;
}

function testDbConnection($host, $port, $db, $user, $pass) {
    try {
        $dsn = "mysql:host={$host};port={$port};dbname={$db}";
        $pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        return ['ok' => true, 'message' => 'Connected successfully'];
    } catch (PDOException $e) {
        return ['ok' => false, 'message' => $e->getMessage()];
    }
}

function writeEnvFile($basePath, $data) {
    $env = "APP_NAME=\"{$data['app_name']}\"\n";
    $env .= "APP_ENV=production\n";
    $env .= "APP_KEY=\n";
    $env .= "APP_DEBUG=false\n";
    $env .= "APP_URL={$data['app_url']}\n\n";
    $env .= "DB_CONNECTION=mysql\n";
    $env .= "DB_HOST={$data['db_host']}\n";
    $env .= "DB_PORT={$data['db_port']}\n";
    $env .= "DB_DATABASE={$data['db_name']}\n";
    $env .= "DB_USERNAME={$data['db_user']}\n";
    $env .= "DB_PASSWORD={$data['db_pass']}\n\n";
    $env .= "SESSION_DRIVER=file\n";
    $env .= "CACHE_STORE=file\n";
    $env .= "QUEUE_CONNECTION=sync\n";
    return file_put_contents($basePath . '/.env', $env) !== false;
}

function runArtisan($basePath, $command) {
    $cmd = "cd " . escapeshellarg($basePath) . " && php artisan {$command} 2>&1";
    $output = shell_exec($cmd);
    return $output;
}

function registerMiddleware($basePath) {
    $kernelPath = $basePath . '/app/Http/Kernel.php';
    if (!file_exists($kernelPath)) return 'Kernel.php not found';
    
    $content = file_get_contents($kernelPath);
    if (strpos($content, 'AdminAuth') !== false) return 'Already registered';
    
    $content = str_replace(
        "'verified' => \\Illuminate\\Auth\\Middleware\\EnsureEmailIsVerified::class,",
        "'verified' => \\Illuminate\\Auth\\Middleware\\EnsureEmailIsVerified::class,\n        'admin' => \\App\\Http\\Middleware\\AdminAuth::class,",
        $content
    );
    file_put_contents($kernelPath, $content);
    return 'Registered successfully';
}

function addCsrfException($basePath) {
    $csrfPath = $basePath . '/app/Http/Middleware/VerifyCsrfToken.php';
    if (!file_exists($csrfPath)) return 'VerifyCsrfToken.php not found';
    
    $content = file_get_contents($csrfPath);
    if (strpos($content, 'admin/api') !== false) return 'Already configured';
    
    $content = str_replace(
        'protected $except = [',
        "protected \$except = [\n        'admin/api/*',",
        $content
    );
    file_put_contents($csrfPath, $content);
    return 'Added successfully';
}

// ─── Process POST Actions ────────────────────────────────

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if ($step === 'test_db') {
        $result = testDbConnection(
            $_POST['db_host'], $_POST['db_port'],
            $_POST['db_name'], $_POST['db_user'], $_POST['db_pass']
        );
        header('Content-Type: application/json');
        echo json_encode($result);
        exit;
    }
    
    if ($step === 'install') {
        header('Content-Type: application/json');
        $log = [];
        
        // 1. Write .env
        $envOk = writeEnvFile($basePath, $_POST);
        $log[] = $envOk ? '✅ .env file created' : '❌ Failed to create .env';
        
        // 2. Generate key
        $keyOut = runArtisan($basePath, 'key:generate --force');
        $log[] = '✅ App key generated';
        
        // 3. Register middleware
        $mwResult = registerMiddleware($basePath);
        $log[] = "✅ Middleware: {$mwResult}";
        
        // 4. CSRF exception
        $csrfResult = addCsrfException($basePath);
        $log[] = "✅ CSRF exception: {$csrfResult}";
        
        // 5. Create directories
        $dirs = ['public/uploads/books', 'public/uploads/covers', 'public/uploads/photos', 'public/uploads/events', 'public/uploads/sermons'];
        foreach ($dirs as $dir) {
            @mkdir($basePath . '/' . $dir, 0775, true);
        }
        @chmod($basePath . '/storage', 0775);
        @chmod($basePath . '/bootstrap/cache', 0775);
        $log[] = '✅ Upload directories created';
        
        // 6. Storage link
        runArtisan($basePath, 'storage:link');
        $log[] = '✅ Storage link created';
        
        // 7. Migrate
        $migrateOut = runArtisan($basePath, 'migrate --force');
        if (strpos($migrateOut, 'ERROR') !== false || strpos($migrateOut, 'error') !== false) {
            $log[] = "❌ Migration issue: " . trim(substr($migrateOut, 0, 200));
        } else {
            $log[] = '✅ Database tables created';
        }
        
        // 8. Seed
        $seedOut = runArtisan($basePath, 'db:seed --force');
        if (strpos($seedOut, 'ERROR') !== false || strpos($seedOut, 'error') !== false) {
            $log[] = "❌ Seeder issue: " . trim(substr($seedOut, 0, 200));
        } else {
            $log[] = '✅ Sample data seeded';
        }
        
        // 9. Update church settings from form
        try {
            $dsn = "mysql:host={$_POST['db_host']};port={$_POST['db_port']};dbname={$_POST['db_name']}";
            $pdo = new PDO($dsn, $_POST['db_user'], $_POST['db_pass']);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $settings = [
                ['general', 'church_name', $_POST['church_name'] ?? 'My Church'],
                ['general', 'tagline', $_POST['tagline'] ?? 'Where Faith Meets Fellowship'],
                ['general', 'pastor', $_POST['pastor'] ?? ''],
                ['general', 'denomination', $_POST['denomination'] ?? ''],
                ['contact', 'address', $_POST['address'] ?? ''],
                ['contact', 'phone', $_POST['phone'] ?? ''],
                ['contact', 'email', $_POST['church_email'] ?? ''],
                ['general', 'about', $_POST['about'] ?? ''],
            ];
            
            foreach ($settings as [$group, $key, $value]) {
                if ($value) {
                    $stmt = $pdo->prepare("UPDATE church_settings SET value = ? WHERE `key` = ?");
                    $stmt->execute([$value, $key]);
                    if ($stmt->rowCount() === 0) {
                        $stmt = $pdo->prepare("INSERT INTO church_settings (`group`, `key`, `value`, created_at, updated_at) VALUES (?, ?, ?, NOW(), NOW())");
                        $stmt->execute([$group, $key, $value]);
                    }
                }
            }
            
            // Update admin email/password if provided
            if (!empty($_POST['admin_email'])) {
                $stmt = $pdo->prepare("UPDATE admin_users SET email = ? WHERE id = 1");
                $stmt->execute([$_POST['admin_email']]);
            }
            if (!empty($_POST['admin_password'])) {
                $hash = password_hash($_POST['admin_password'], PASSWORD_BCRYPT, ['cost' => 12]);
                $stmt = $pdo->prepare("UPDATE admin_users SET password = ? WHERE id = 1");
                $stmt->execute([$hash]);
            }
            
            $log[] = '✅ Church settings saved';
        } catch (Exception $e) {
            $log[] = '⚠️ Settings update: ' . $e->getMessage();
        }
        
        // 10. Clear caches
        runArtisan($basePath, 'config:clear');
        runArtisan($basePath, 'cache:clear');
        runArtisan($basePath, 'route:clear');
        runArtisan($basePath, 'view:clear');
        $log[] = '✅ Caches cleared';
        
        echo json_encode(['success' => true, 'log' => $log]);
        exit;
    }
    
    if ($step === 'finish') {
        // Self-delete installer
        @unlink(__FILE__);
        header('Location: /admin');
        exit;
    }
}

// ─── HTML GUI ────────────────────────────────────────────
$checks = checkRequirements($basePath);
$allOk = !in_array(false, array_column($checks, 'ok'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>✝ Church Platform Installer</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{--bg:#0B0D11;--card:#13161D;--gold:#C9A84C;--gold2:#9B7A2F;--tx:#E8E6E1;--tx2:#8A8780;--border:#1E2129;--green:#22C55E;--red:#EF4444;--blue:#3B82F6}
body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--tx);min-height:100vh;display:flex;justify-content:center;align-items:flex-start;padding:30px 15px}
.installer{max-width:700px;width:100%;margin:0 auto}
.logo{text-align:center;margin-bottom:30px}
.logo h1{font-family:'Playfair Display',serif;font-size:2rem;color:var(--gold);margin-bottom:4px}
.logo p{color:var(--tx2);font-size:.9rem}
.card{background:var(--card);border:1px solid var(--border);border-radius:12px;padding:28px;margin-bottom:20px}
.card h2{font-family:'Playfair Display',serif;font-size:1.3rem;color:var(--gold);margin-bottom:16px;padding-bottom:10px;border-bottom:1px solid var(--border)}
.steps{display:flex;gap:8px;margin-bottom:24px;flex-wrap:wrap}
.step-dot{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.8rem;font-weight:600;background:var(--border);color:var(--tx2);transition:.3s}
.step-dot.active{background:var(--gold);color:#000}
.step-dot.done{background:var(--green);color:#fff}
.check-row{display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border)}
.check-row:last-child{border:none}
.check-ok{color:var(--green);font-weight:600;font-size:.85rem}
.check-fail{color:var(--red);font-weight:600;font-size:.85rem}
.form-group{margin-bottom:16px}
.form-group label{display:block;font-size:.85rem;color:var(--tx2);margin-bottom:5px;font-weight:500}
.form-group input,.form-group select,.form-group textarea{width:100%;padding:10px 14px;border:1px solid var(--border);border-radius:8px;background:var(--bg);color:var(--tx);font-size:.9rem;font-family:inherit}
.form-group input:focus,.form-group textarea:focus{outline:none;border-color:var(--gold)}
.form-group textarea{height:80px;resize:vertical}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.btn{display:inline-flex;align-items:center;justify-content:center;padding:12px 28px;border:none;border-radius:8px;font-size:.95rem;font-weight:600;cursor:pointer;font-family:inherit;transition:.3s;gap:8px}
.btn-gold{background:var(--gold);color:#000}.btn-gold:hover{background:var(--gold2)}
.btn-outline{background:transparent;border:1px solid var(--border);color:var(--tx)}.btn-outline:hover{border-color:var(--gold)}
.btn:disabled{opacity:.5;cursor:not-allowed}
.btn-row{display:flex;justify-content:space-between;margin-top:20px;gap:12px}
.db-test{padding:6px 16px;font-size:.8rem;border-radius:6px;background:var(--blue);color:#fff;border:none;cursor:pointer;font-family:inherit}
.db-test:hover{opacity:.9}
.db-result{font-size:.82rem;margin-top:6px;padding:6px 10px;border-radius:6px;display:none}
.db-result.ok{display:block;background:rgba(34,197,94,.1);color:var(--green);border:1px solid rgba(34,197,94,.2)}
.db-result.fail{display:block;background:rgba(239,68,68,.1);color:var(--red);border:1px solid rgba(239,68,68,.2)}
.install-log{background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:14px;font-family:monospace;font-size:.82rem;max-height:350px;overflow-y:auto;line-height:1.8}
.install-log .line{padding:2px 0}
.progress-bar{width:100%;height:6px;background:var(--border);border-radius:3px;margin:14px 0;overflow:hidden}
.progress-fill{height:100%;background:var(--gold);border-radius:3px;transition:width .5s ease;width:0}
.section-title{font-size:.9rem;font-weight:600;color:var(--tx);margin:18px 0 8px;display:flex;align-items:center;gap:8px}
.section-title span{color:var(--gold)}
.hidden{display:none}
.success-box{text-align:center;padding:30px 20px}
.success-box .icon{font-size:3rem;margin-bottom:10px}
.success-box h2{font-family:'Playfair Display',serif;color:var(--gold);font-size:1.5rem;margin-bottom:8px}
.success-box p{color:var(--tx2);margin-bottom:4px}
.cred-box{background:var(--bg);border:1px solid var(--border);border-radius:8px;padding:16px;margin:18px auto;max-width:350px;text-align:left}
.cred-row{display:flex;justify-content:space-between;padding:4px 0;font-size:.9rem}
.cred-row .lbl{color:var(--tx2)}
.cred-row .val{color:var(--gold);font-weight:600}
@media(max-width:600px){.form-row{grid-template-columns:1fr}.steps{gap:4px}.step-dot{width:30px;height:30px;font-size:.7rem}}
</style>
</head>
<body>
<div class="installer">
    <div class="logo">
        <h1>✝ Church Platform</h1>
        <p>Installation Wizard</p>
    </div>

    <!-- Step Indicators -->
    <div class="steps" id="stepDots">
        <div class="step-dot active" data-step="1">1</div>
        <div class="step-dot" data-step="2">2</div>
        <div class="step-dot" data-step="3">3</div>
        <div class="step-dot" data-step="4">4</div>
        <div class="step-dot" data-step="5">5</div>
    </div>

    <!-- STEP 1: Requirements -->
    <div class="card" id="step1">
        <h2>📋 Step 1: System Requirements</h2>
        <?php foreach ($checks as $key => $check): ?>
        <div class="check-row">
            <span><?= $check['label'] ?></span>
            <span class="<?= $check['ok'] ? 'check-ok' : 'check-fail' ?>">
                <?= $check['ok'] ? '✅' : '❌' ?> <?= $check['value'] ?>
            </span>
        </div>
        <?php endforeach; ?>
        <div class="btn-row">
            <span></span>
            <button class="btn btn-gold" onclick="goStep(2)" <?= $allOk ? '' : 'disabled' ?>>
                <?= $allOk ? 'Continue →' : 'Fix Requirements First' ?>
            </button>
        </div>
    </div>

    <!-- STEP 2: Database -->
    <div class="card hidden" id="step2">
        <h2>🗄️ Step 2: Database Configuration</h2>
        <div class="form-row">
            <div class="form-group">
                <label>Database Host</label>
                <input type="text" id="db_host" value="127.0.0.1">
            </div>
            <div class="form-group">
                <label>Port</label>
                <input type="text" id="db_port" value="3306">
            </div>
        </div>
        <div class="form-group">
            <label>Database Name</label>
            <input type="text" id="db_name" placeholder="church_db">
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Username</label>
                <input type="text" id="db_user" placeholder="root">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" id="db_pass" placeholder="password">
            </div>
        </div>
        <button class="db-test" onclick="testDb()">🔌 Test Connection</button>
        <div class="db-result" id="dbResult"></div>
        <div class="btn-row">
            <button class="btn btn-outline" onclick="goStep(1)">← Back</button>
            <button class="btn btn-gold" id="dbNext" onclick="goStep(3)" disabled>Continue →</button>
        </div>
    </div>

    <!-- STEP 3: Church Info -->
    <div class="card hidden" id="step3">
        <h2>⛪ Step 3: Church Information</h2>
        <div class="form-group">
            <label>Church Name *</label>
            <input type="text" id="church_name" placeholder="Grace Community Church" value="">
        </div>
        <div class="form-group">
            <label>Tagline</label>
            <input type="text" id="tagline" placeholder="Where Faith Meets Fellowship">
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Pastor / Lead Minister</label>
                <input type="text" id="pastor" placeholder="Rev. John Smith">
            </div>
            <div class="form-group">
                <label>Denomination</label>
                <input type="text" id="denomination" placeholder="Non-Denominational">
            </div>
        </div>
        <div class="form-group">
            <label>Address</label>
            <input type="text" id="address" placeholder="123 Faith Avenue, City, ST 12345">
        </div>
        <div class="form-row">
            <div class="form-group">
                <label>Phone</label>
                <input type="text" id="phone" placeholder="+1 (555) 123-4567">
            </div>
            <div class="form-group">
                <label>Church Email</label>
                <input type="email" id="church_email" placeholder="info@church.com">
            </div>
        </div>
        <div class="form-group">
            <label>About (short description)</label>
            <textarea id="about" placeholder="Brief description of your church..."></textarea>
        </div>
        <div class="form-group">
            <label>Website URL</label>
            <input type="text" id="app_url" placeholder="https://yourchurch.com" value="<?= 'https://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') ?>">
        </div>
        <div class="btn-row">
            <button class="btn btn-outline" onclick="goStep(2)">← Back</button>
            <button class="btn btn-gold" onclick="goStep(4)">Continue →</button>
        </div>
    </div>

    <!-- STEP 4: Admin Account -->
    <div class="card hidden" id="step4">
        <h2>🔐 Step 4: Admin Account</h2>
        <p style="color:var(--tx2);font-size:.85rem;margin-bottom:14px">Set your admin login credentials for the church dashboard.</p>
        <div class="form-group">
            <label>Admin Email *</label>
            <input type="email" id="admin_email" value="admin@church.com" placeholder="admin@church.com">
        </div>
        <div class="form-group">
            <label>Admin Password *</label>
            <input type="password" id="admin_password" value="" placeholder="Choose a strong password">
        </div>
        <div class="btn-row">
            <button class="btn btn-outline" onclick="goStep(3)">← Back</button>
            <button class="btn btn-gold" onclick="runInstall()">🚀 Install Now</button>
        </div>
    </div>

    <!-- STEP 5: Installing / Complete -->
    <div class="card hidden" id="step5">
        <div id="installing">
            <h2>⚙️ Installing...</h2>
            <div class="progress-bar"><div class="progress-fill" id="progressFill"></div></div>
            <div class="install-log" id="installLog">
                <div class="line" style="color:var(--tx2)">Starting installation...</div>
            </div>
        </div>
        <div id="complete" class="hidden">
            <div class="success-box">
                <div class="icon">🎉</div>
                <h2>Installation Complete!</h2>
                <p>Your Church Platform is ready to use.</p>
                <div class="cred-box">
                    <div class="cred-row"><span class="lbl">Admin URL</span><span class="val" id="finalUrl">/admin</span></div>
                    <div class="cred-row"><span class="lbl">Email</span><span class="val" id="finalEmail">admin@church.com</span></div>
                    <div class="cred-row"><span class="lbl">Password</span><span class="val" id="finalPass">••••••</span></div>
                </div>
                <div style="margin-top:18px;display:flex;gap:10px;justify-content:center;flex-wrap:wrap">
                    <a href="/" class="btn btn-outline">🌐 View Website</a>
                    <a href="/admin" class="btn btn-gold" onclick="selfDelete()">🔐 Go to Admin</a>
                </div>
                <p style="color:var(--red);font-size:.8rem;margin-top:14px">⚠️ The installer file will be deleted for security when you click "Go to Admin".</p>
            </div>
        </div>
    </div>
</div>

<script>
let currentStep = 1;
let dbVerified = false;

function goStep(n) {
    // Validation
    if (n === 3 && !dbVerified) { alert('Please test your database connection first.'); return; }
    if (n === 4 && !document.getElementById('church_name').value.trim()) { alert('Church name is required.'); return; }
    
    document.querySelectorAll('.card').forEach(c => c.classList.add('hidden'));
    document.getElementById('step' + n).classList.remove('hidden');
    
    document.querySelectorAll('.step-dot').forEach(d => {
        let s = parseInt(d.dataset.step);
        d.classList.remove('active', 'done');
        if (s < n) d.classList.add('done');
        if (s === n) d.classList.add('active');
    });
    currentStep = n;
}

function testDb() {
    let btn = document.querySelector('.db-test');
    let res = document.getElementById('dbResult');
    btn.textContent = '⏳ Testing...';
    
    let fd = new FormData();
    fd.append('step', 'test_db');
    fd.append('db_host', document.getElementById('db_host').value);
    fd.append('db_port', document.getElementById('db_port').value);
    fd.append('db_name', document.getElementById('db_name').value);
    fd.append('db_user', document.getElementById('db_user').value);
    fd.append('db_pass', document.getElementById('db_pass').value);
    
    fetch('', {method: 'POST', body: fd})
        .then(r => r.json())
        .then(d => {
            res.className = 'db-result ' + (d.ok ? 'ok' : 'fail');
            res.textContent = d.ok ? '✅ ' + d.message : '❌ ' + d.message;
            btn.textContent = '🔌 Test Connection';
            dbVerified = d.ok;
            document.getElementById('dbNext').disabled = !d.ok;
        })
        .catch(e => {
            res.className = 'db-result fail';
            res.textContent = '❌ Request failed: ' + e.message;
            btn.textContent = '🔌 Test Connection';
        });
}

function runInstall() {
    let email = document.getElementById('admin_email').value.trim();
    let pass = document.getElementById('admin_password').value;
    if (!email) { alert('Admin email is required.'); return; }
    if (!pass || pass.length < 6) { alert('Password must be at least 6 characters.'); return; }
    
    goStep(5);
    let log = document.getElementById('installLog');
    let fill = document.getElementById('progressFill');
    
    fill.style.width = '20%';
    log.innerHTML = '<div class="line" style="color:var(--gold)">⏳ Running installation... Please wait.</div>';
    
    let fd = new FormData();
    fd.append('step', 'install');
    fd.append('db_host', document.getElementById('db_host').value);
    fd.append('db_port', document.getElementById('db_port').value);
    fd.append('db_name', document.getElementById('db_name').value);
    fd.append('db_user', document.getElementById('db_user').value);
    fd.append('db_pass', document.getElementById('db_pass').value);
    fd.append('app_name', document.getElementById('church_name').value);
    fd.append('app_url', document.getElementById('app_url').value);
    fd.append('church_name', document.getElementById('church_name').value);
    fd.append('tagline', document.getElementById('tagline').value);
    fd.append('pastor', document.getElementById('pastor').value);
    fd.append('denomination', document.getElementById('denomination').value);
    fd.append('address', document.getElementById('address').value);
    fd.append('phone', document.getElementById('phone').value);
    fd.append('church_email', document.getElementById('church_email').value);
    fd.append('about', document.getElementById('about').value);
    fd.append('admin_email', email);
    fd.append('admin_password', pass);
    
    fill.style.width = '50%';
    
    fetch('', {method: 'POST', body: fd})
        .then(r => r.json())
        .then(d => {
            fill.style.width = '100%';
            log.innerHTML = '';
            d.log.forEach(line => {
                let color = line.startsWith('✅') ? 'var(--green)' : line.startsWith('❌') ? 'var(--red)' : 'var(--gold)';
                log.innerHTML += `<div class="line" style="color:${color}">${line}</div>`;
            });
            
            setTimeout(() => {
                document.getElementById('installing').classList.add('hidden');
                document.getElementById('complete').classList.remove('hidden');
                document.getElementById('finalUrl').textContent = document.getElementById('app_url').value + '/admin';
                document.getElementById('finalEmail').textContent = email;
                document.getElementById('finalPass').textContent = '(as you entered)';
            }, 1000);
        })
        .catch(e => {
            fill.style.width = '100%';
            fill.style.background = 'var(--red)';
            log.innerHTML += `<div class="line" style="color:var(--red)">❌ Error: ${e.message}</div>`;
        });
}

function selfDelete() {
    fetch('', {method: 'POST', body: new URLSearchParams({step: 'finish'})}).catch(() => {});
}
</script>
</body>
</html>
