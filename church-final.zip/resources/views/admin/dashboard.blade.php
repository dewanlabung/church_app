<!DOCTYPE html><html lang="en" data-theme="dark"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Church Admin</title><meta name="csrf-token" content="{{ csrf_token() }}">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/css/admin.css"></head><body>
<div class="sb" id="sb"><div class="sb-hd"><div class="sb-ic">✝</div><span class="sb-nm">Church Admin</span></div><nav class="sb-nv" id="nv"></nav><div class="sb-ft">
<a href="/" target="_blank" class="sb-link">🌐 View Site</a>
<form method="POST" action="/admin/logout" style="margin-top:6px">@csrf<button type="submit" class="sb-link sb-out">🚪 Logout</button></form></div></div>
<div class="ov" id="ov" onclick="tg()"></div>
<div class="mn"><div class="tb"><div style="display:flex;align-items:center;gap:10px"><button class="mb" onclick="tg()">☰</button><span class="tb-t" id="pt">Dashboard</span></div>
<div style="display:flex;align-items:center;gap:8px"><span style="font-size:.82rem;color:var(--tx2)">{{ session('admin_user.name','Admin') }}</span><button class="th" onclick="thm()"><span id="ti">🌙</span></button></div></div>
<div class="ct" id="ct"></div></div>
<div class="md-bg" id="md" onclick="if(event.target===this)cm()"><div class="md"><div class="md-h"><span class="md-t" id="mt">Edit</span><button class="md-x" onclick="cm()">✕</button></div><div class="md-b" id="mb"></div></div></div>
<div class="to" id="to"></div>
<script>const CSRF='{{ csrf_token() }}';</script><script src="/js/admin.js"></script></body></html>
