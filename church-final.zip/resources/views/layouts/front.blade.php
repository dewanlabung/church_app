<!DOCTYPE html>
<html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>{{ $seo->title ?? ($churchSettings['church_name'] ?? 'Church') }} - @yield('title')</title>
<meta name="description" content="{{ $seo->description ?? ($churchSettings['mission'] ?? '') }}">
@if(isset($seo->keywords))<meta name="keywords" content="{{ $seo->keywords }}">@endif
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=Playfair+Display:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/css/front.css">
</head><body>
<nav class="nav">
<div class="nav-inner">
<a href="/" class="nav-brand">✝ {{ $churchSettings['church_name'] ?? 'Church' }}</a>
<button class="nav-toggle" onclick="this.closest('.nav').classList.toggle('open')">☰</button>
<div class="nav-links">
<a href="/">Home</a><a href="/about">About</a><a href="/events">Events</a><a href="/sermons">Sermons</a>
<a href="/library">Library</a><a href="/prayers">Prayers</a><a href="/giving" class="nav-cta">Give</a>
</div></div></nav>
<main>@yield('content')</main>
<footer class="footer">
<div class="footer-inner">
<div class="footer-col"><h3>{{ $churchSettings['church_name'] ?? 'Church' }}</h3><p>{{ $churchSettings['mission'] ?? '' }}</p></div>
<div class="footer-col"><h3>Connect</h3>
@if(!empty($churchSettings['facebook']))<a href="{{ $churchSettings['facebook'] }}" target="_blank">Facebook</a>@endif
@if(!empty($churchSettings['youtube']))<a href="{{ $churchSettings['youtube'] }}" target="_blank">YouTube</a>@endif
@if(!empty($churchSettings['instagram']))<a href="{{ $churchSettings['instagram'] }}" target="_blank">Instagram</a>@endif
</div>
<div class="footer-col"><h3>Visit</h3><p>{{ $churchSettings['address'] ?? '' }}</p><p>{{ $churchSettings['phone'] ?? '' }}</p></div>
</div><div class="footer-bottom">© {{ date('Y') }} {{ $churchSettings['church_name'] ?? 'Church' }}. All rights reserved.</div>
</footer>
<script>document.querySelectorAll('.nav-links a').forEach(a=>{if(a.getAttribute('href')===window.location.pathname)a.classList.add('active')})</script>
@yield('scripts')
</body></html>
