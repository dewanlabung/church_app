@extends('layouts.front')
@section('title', 'Library')
@section('content')
<section class="section"><div class="section-inner">
<h1 class="page-title">Library</h1>
<p>Content coming soon. Manage in the admin panel.</p>
</div></section>
@endsection
