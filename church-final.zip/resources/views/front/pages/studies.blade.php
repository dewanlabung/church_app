@extends('layouts.front')
@section('title', 'Studies')
@section('content')
<section class="section"><div class="section-inner">
<h1 class="page-title">Studies</h1>
<p>Content coming soon. Manage in the admin panel.</p>
</div></section>
@endsection
