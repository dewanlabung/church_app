@extends('layouts.front')
@section('title', 'Directory')
@section('content')
<section class="section"><div class="section-inner">
<h1 class="page-title">Directory</h1>
<p>Content coming soon. Manage in the admin panel.</p>
</div></section>
@endsection
