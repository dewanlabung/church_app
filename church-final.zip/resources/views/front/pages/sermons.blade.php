@extends('layouts.front')
@section('title', 'Sermons')
@section('content')
<section class="section"><div class="section-inner">
<h1 class="page-title">Sermons</h1>
<p>Content coming soon. Manage in the admin panel.</p>
</div></section>
@endsection
