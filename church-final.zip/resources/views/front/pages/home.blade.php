@extends('layouts.front')
@section('content')
<section class="hero">
  <div class="hero-in">
    <h1>{{ $churchSettings['church_name'] ?? 'Welcome' }}</h1>
    <p class="hero-tag">{{ $churchSettings['tagline'] ?? 'Where Faith Meets Fellowship' }}</p>
    <div class="hero-btns"><a href="/events" class="btn-g">Upcoming Events</a><a href="/about" class="btn-o">Learn More</a></div>
  </div>
</section>

@if($verse)
<section class="sec">
  <div class="sec-in">
    <div class="verse-card">
      <div class="verse-label">📖 Verse of the Day</div>
      <blockquote class="verse-text">"{{ $verse->text }}"</blockquote>
      <cite class="verse-ref">— {{ $verse->reference }}</cite>
    </div>
  </div>
</section>
@endif

@if($blessing)
<section class="sec sec-alt">
  <div class="sec-in">
    <div class="verse-card bless-card">
      <div class="verse-label">✨ {{ $blessing->title }}</div>
      <blockquote class="verse-text">"{{ $blessing->text }}"</blockquote>
      @if($blessing->author)<cite class="verse-ref">— {{ $blessing->author }}</cite>@endif
    </div>
  </div>
</section>
@endif

@if($announcements->count())
<section class="sec">
  <div class="sec-in">
    <h2 class="sec-title">📢 Announcements</h2>
    <div class="grid3">
      @foreach($announcements as $a)
      <div class="card">
        <div class="card-badge {{ $a->priority }}">{{ ucfirst($a->priority) }}</div>
        <h3>{{ $a->title }}</h3>
        <p>{{ Str::limit($a->content, 120) }}</p>
      </div>
      @endforeach
    </div>
  </div>
</section>
@endif

@if($events->count())
<section class="sec sec-alt">
  <div class="sec-in">
    <h2 class="sec-title">📅 Upcoming Events</h2>
    <div class="grid3">
      @foreach($events as $e)
      <div class="card">
        <div class="card-date">{{ $e->event_date->format('M d') }}</div>
        <h3>{{ $e->title }}</h3>
        <p class="card-meta">{{ $e->event_time ? \Carbon\Carbon::parse($e->event_time)->format('g:i A') : '' }} {{ $e->location ? '• '.$e->location : '' }}</p>
        <p>{{ Str::limit($e->description, 100) }}</p>
      </div>
      @endforeach
    </div>
    <div style="text-align:center;margin-top:20px"><a href="/events" class="btn-o">View All Events →</a></div>
  </div>
</section>
@endif

@if($sermons->count())
<section class="sec">
  <div class="sec-in">
    <h2 class="sec-title">🎙️ Recent Sermons</h2>
    <div class="grid3">
      @foreach($sermons as $s)
      <div class="card">
        <h3>{{ $s->title }}</h3>
        <p class="card-meta">{{ $s->speaker }} • {{ $s->sermon_date->format('M d, Y') }} {{ $s->duration ? '• '.$s->duration : '' }}</p>
        <p>{{ Str::limit($s->description, 100) }}</p>
        @if($s->series)<span class="tag">{{ $s->series }}</span>@endif
      </div>
      @endforeach
    </div>
    <div style="text-align:center;margin-top:20px"><a href="/sermons" class="btn-o">All Sermons →</a></div>
  </div>
</section>
@endif

@if($prayers->count())
<section class="sec sec-alt">
  <div class="sec-in">
    <h2 class="sec-title">🙏 Prayer Wall</h2>
    <div class="grid2">
      @foreach($prayers as $p)
      <div class="card prayer-card">
        <div class="prayer-name">{{ $p->is_anonymous ? 'Anonymous' : $p->name }}</div>
        <p>{{ Str::limit($p->request, 150) }}</p>
        <form method="POST" action="/prayers/{{ $p->id }}/pray" style="display:inline">@csrf<button type="submit" class="btn-pray">🙏 Pray ({{ $p->prayer_count }})</button></form>
      </div>
      @endforeach
    </div>
    <div style="text-align:center;margin-top:20px"><a href="/prayers" class="btn-o">View Prayer Wall →</a></div>
  </div>
</section>
@endif

@if($reviews->count())
<section class="sec">
  <div class="sec-in">
    <h2 class="sec-title">⭐ What People Say</h2>
    <div class="grid3">
      @foreach($reviews as $r)
      <div class="card">
        <div class="stars">{!! str_repeat('★', $r->rating) . str_repeat('☆', 5-$r->rating) !!}</div>
        <p>"{{ Str::limit($r->text, 120) }}"</p>
        <div class="card-meta">— {{ $r->name }}</div>
      </div>
      @endforeach
    </div>
  </div>
</section>
@endif

@if($devotional)
<section class="sec sec-alt">
  <div class="sec-in">
    <div class="verse-card">
      <div class="verse-label">🕊️ Today's Devotional: {{ $devotional->title }}</div>
      <cite class="verse-ref" style="margin-bottom:12px">{{ $devotional->verse }}</cite>
      <p style="line-height:1.8">{{ Str::limit($devotional->content, 300) }}</p>
      <div class="card-meta" style="margin-top:10px">— {{ $devotional->author }}</div>
    </div>
  </div>
</section>
@endif
@endsection
