@extends('layouts.front')
@section('title', 'Giving')
@section('content')
<section class="section"><div class="section-inner">
<h1 class="page-title">Giving</h1>
<p>Content coming soon. Manage in the admin panel.</p>
</div></section>
@endsection
