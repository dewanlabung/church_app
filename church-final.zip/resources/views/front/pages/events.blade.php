@extends('layouts.front')
@section('title', 'Events')
@section('content')
<section class="section"><div class="section-inner">
<h1 class="page-title">Events</h1>
<p>Content coming soon. Manage in the admin panel.</p>
</div></section>
@endsection
