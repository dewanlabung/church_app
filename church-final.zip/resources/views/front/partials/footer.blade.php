<footer class="ftr">
<div class="ftr-in">
  <div class="ftr-col">
    <h3>{{ $churchSettings['church_name'] ?? 'Church' }}</h3>
    <p>{{ $churchSettings['tagline'] ?? '' }}</p>
    <p style="margin-top:8px;font-size:.82rem">{{ $churchSettings['address'] ?? '' }}</p>
    <p style="font-size:.82rem">{{ $churchSettings['phone'] ?? '' }}</p>
  </div>
  <div class="ftr-col">
    <h4>Quick Links</h4>
    <a href="/events">Events</a>
    <a href="/sermons">Sermons</a>
    <a href="/library">Library</a>
    <a href="/prayers">Prayer Wall</a>
  </div>
  <div class="ftr-col">
    <h4>Connect</h4>
    @if(!empty($churchSettings['facebook']))<a href="{{ $churchSettings['facebook'] }}" target="_blank">Facebook</a>@endif
    @if(!empty($churchSettings['youtube']))<a href="{{ $churchSettings['youtube'] }}" target="_blank">YouTube</a>@endif
    @if(!empty($churchSettings['instagram']))<a href="{{ $churchSettings['instagram'] }}" target="_blank">Instagram</a>@endif
    <a href="/contact">Contact Us</a>
  </div>
</div>
<div class="ftr-btm">&copy; {{ date('Y') }} {{ $churchSettings['church_name'] ?? 'Church' }}. All rights reserved.</div>
</footer>
