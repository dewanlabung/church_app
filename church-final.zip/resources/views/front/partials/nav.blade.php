<header class="hdr">
<div class="hdr-in">
  <a href="/" class="hdr-brand"><span class="hdr-icon">✝</span> <span class="hdr-name">{{ $churchSettings['church_name'] ?? 'Church' }}</span></a>
  <button class="hdr-toggle" onclick="document.querySelector('.hdr-nav').classList.toggle('open')">☰</button>
  <nav class="hdr-nav">
    <a href="/">Home</a>
    <a href="/events">Events</a>
    <a href="/sermons">Sermons</a>
    <a href="/library">Library</a>
    <a href="/prayers">Prayers</a>
    <a href="/studies">Studies</a>
    <a href="/volunteer">Volunteer</a>
    <a href="/giving">Giving</a>
    <a href="/about">About</a>
    <a href="/contact">Contact</a>
  </nav>
</div>
</header>
