<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>Admin Login</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
<style>*{margin:0;padding:0;box-sizing:border-box}body{background:#0B0D11;color:#E8E4DC;font-family:'DM Sans',sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px}
.box{background:#12151C;border:1px solid rgba(201,168,76,.12);border-radius:20px;padding:40px;max-width:380px;width:100%}
.logo{text-align:center;margin-bottom:28px}.logo i{font-size:2.2rem}.logo h1{font-family:'Playfair Display';font-size:1.2rem;color:#C9A84C;margin-top:6px}
.fg{margin-bottom:14px}.fg label{display:block;font-size:.7rem;font-weight:700;color:#9A9488;text-transform:uppercase;letter-spacing:.1em;margin-bottom:4px}
.fi{width:100%;background:#0B0D11;border:1px solid rgba(201,168,76,.15);border-radius:10px;padding:11px 14px;color:#E8E4DC;font-family:'DM Sans';font-size:.88rem;outline:none}.fi:focus{border-color:#C9A84C}
.btn{width:100%;padding:11px;border-radius:10px;border:none;background:linear-gradient(135deg,#A07C28,#C9A84C);color:#0B0D11;font-family:'DM Sans';font-size:.88rem;font-weight:700;cursor:pointer;margin-top:6px}
.err{background:rgba(216,85,85,.12);border:1px solid rgba(216,85,85,.2);border-radius:10px;padding:10px;color:#D85555;font-size:.82rem;margin-bottom:14px}</style></head><body>
<div class="box"><div class="logo"><div style="font-size:2.2rem">✝</div><h1>Church Admin</h1></div>
@if($errors->any())<div class="err">{{ $errors->first() }}</div>@endif
<form method="POST" action="/admin/login">@csrf
<div class="fg"><label>Email</label><input class="fi" type="email" name="email" value="{{ old('email') }}" required autofocus></div>
<div class="fg"><label>Password</label><input class="fi" type="password" name="password" required></div>
<button type="submit" class="btn">Sign In</button></form></div></body></html>
