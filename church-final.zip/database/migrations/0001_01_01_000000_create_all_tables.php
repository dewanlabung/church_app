<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        // ── Admin Users ──────────────────────────────────
        Schema::create('admin_users', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email')->unique();
            $table->string('password');
            $table->string('role')->default('admin'); // admin, editor
            $table->string('avatar')->nullable();
            $table->rememberToken();
            $table->timestamps();
        });

        // ── Categories (shared across content types) ─────
        Schema::create('categories', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->string('type'); // event, book, study, sermon, directory
            $table->string('icon', 10)->nullable();
            $table->string('color', 20)->nullable();
            $table->text('description')->nullable();
            $table->integer('sort_order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->index(['type', 'is_active']);
        });

        // ── SEO Meta Tags ────────────────────────────────
        Schema::create('seo_meta', function (Blueprint $table) {
            $table->id();
            $table->string('page_slug')->unique(); // home, about, events, sermons, etc.
            $table->string('title')->nullable();
            $table->text('description')->nullable();
            $table->string('keywords')->nullable();
            $table->string('og_image')->nullable();
            $table->string('canonical_url')->nullable();
            $table->timestamps();
        });

        // ── Church Settings (key-value) ──────────────────
        Schema::create('church_settings', function (Blueprint $table) {
            $table->id();
            $table->string('group')->default('general'); // general, contact, social, appearance, seo
            $table->string('key')->unique();
            $table->text('value')->nullable();
            $table->timestamps();
        });

        // ── Verses ───────────────────────────────────────
        Schema::create('verses', function (Blueprint $table) {
            $table->id();
            $table->text('text');
            $table->string('reference', 150);
            $table->date('display_date')->index();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // ── Blessings ────────────────────────────────────
        Schema::create('blessings', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('text');
            $table->string('author')->nullable();
            $table->date('display_date')->index();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // ── Prayer Requests ──────────────────────────────
        Schema::create('prayer_requests', function (Blueprint $table) {
            $table->id();
            $table->string('name')->default('Anonymous');
            $table->text('request');
            $table->boolean('is_anonymous')->default(false);
            $table->unsignedInteger('prayer_count')->default(0);
            $table->enum('status', ['pending', 'active', 'answered', 'archived'])->default('pending');
            $table->boolean('is_approved')->default(false);
            $table->string('ip_address', 45)->nullable();
            $table->timestamps();
            $table->index('status');
        });

        Schema::create('prayer_prays', function (Blueprint $table) {
            $table->id();
            $table->foreignId('prayer_request_id')->constrained()->cascadeOnDelete();
            $table->string('ip_address', 45)->nullable();
            $table->timestamps();
        });

        // ── Events ───────────────────────────────────────
        Schema::create('events', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->date('event_date');
            $table->time('event_time')->nullable();
            $table->date('end_date')->nullable();
            $table->time('end_time')->nullable();
            $table->string('location')->nullable();
            $table->foreignId('category_id')->nullable()->constrained()->nullOnDelete();
            $table->string('image')->nullable();
            $table->boolean('is_recurring')->default(false);
            $table->string('recurrence_pattern')->nullable();
            $table->boolean('is_featured')->default(false);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->index('event_date');
        });

        Schema::create('event_rsvps', function (Blueprint $table) {
            $table->id();
            $table->foreignId('event_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('email')->nullable();
            $table->string('phone', 20)->nullable();
            $table->unsignedInteger('guests')->default(1);
            $table->timestamps();
        });

        // ── Books ────────────────────────────────────────
        Schema::create('books', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('slug')->unique();
            $table->string('author');
            $table->foreignId('category_id')->nullable()->constrained()->nullOnDelete();
            $table->text('description')->nullable();
            $table->string('cover_image')->nullable();
            $table->string('pdf_path')->nullable();
            $table->unsignedInteger('pages')->default(0);
            $table->string('isbn', 20)->nullable();
            $table->boolean('has_pdf')->default(false);
            $table->unsignedInteger('download_count')->default(0);
            $table->boolean('is_featured')->default(false);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // ── Bible Studies ────────────────────────────────
        Schema::create('bible_studies', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->foreignId('category_id')->nullable()->constrained()->nullOnDelete();
            $table->string('leader');
            $table->unsignedInteger('total_weeks')->default(1);
            $table->unsignedInteger('current_week')->default(1);
            $table->unsignedInteger('participant_count')->default(0);
            $table->unsignedInteger('max_participants')->nullable();
            $table->string('meeting_day')->nullable();
            $table->time('meeting_time')->nullable();
            $table->string('location')->nullable();
            $table->string('materials_pdf')->nullable();
            $table->enum('status', ['upcoming', 'active', 'completed'])->default('upcoming');
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('bible_study_participants', function (Blueprint $table) {
            $table->id();
            $table->foreignId('bible_study_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('email')->nullable();
            $table->string('phone', 20)->nullable();
            $table->timestamps();
        });

        // ── Sermons ──────────────────────────────────────
        Schema::create('sermons', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('slug')->unique();
            $table->string('speaker');
            $table->text('description')->nullable();
            $table->date('sermon_date');
            $table->string('duration', 50)->nullable();
            $table->string('series')->nullable();
            $table->foreignId('category_id')->nullable()->constrained()->nullOnDelete();
            $table->string('audio_url')->nullable();
            $table->string('video_url')->nullable();
            $table->string('notes_pdf')->nullable();
            $table->string('thumbnail')->nullable();
            $table->unsignedInteger('view_count')->default(0);
            $table->boolean('is_featured')->default(false);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
            $table->index('sermon_date');
        });

        // ── Devotionals ──────────────────────────────────
        Schema::create('devotionals', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->string('verse');
            $table->text('content');
            $table->string('author');
            $table->date('display_date')->index();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // ── Reviews ──────────────────────────────────────
        Schema::create('reviews', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->text('text');
            $table->unsignedTinyInteger('rating');
            $table->boolean('is_approved')->default(false);
            $table->string('ip_address', 45)->nullable();
            $table->timestamps();
        });

        // ── Volunteer Ministries ─────────────────────────
        Schema::create('volunteer_ministries', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->text('description')->nullable();
            $table->string('icon', 10)->default('🤝');
            $table->unsignedInteger('spots_available')->nullable();
            $table->string('contact_name')->nullable();
            $table->string('contact_email')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('volunteer_signups', function (Blueprint $table) {
            $table->id();
            $table->foreignId('volunteer_ministry_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('email')->nullable();
            $table->string('phone', 20)->nullable();
            $table->text('message')->nullable();
            $table->timestamps();
        });

        // ── Donations ────────────────────────────────────
        Schema::create('donations', function (Blueprint $table) {
            $table->id();
            $table->decimal('amount', 10, 2);
            $table->string('donor_name')->nullable();
            $table->string('donor_email')->nullable();
            $table->enum('frequency', ['one-time', 'weekly', 'monthly'])->default('one-time');
            $table->string('payment_method', 50)->nullable();
            $table->string('transaction_id')->nullable();
            $table->enum('status', ['pending', 'completed', 'failed'])->default('pending');
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->index('status');
        });

        // ── Announcements ────────────────────────────────
        Schema::create('announcements', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('content');
            $table->enum('priority', ['normal', 'important', 'urgent'])->default('normal');
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        // ── Church Directory ─────────────────────────────
        Schema::create('directory_members', function (Blueprint $table) {
            $table->id();
            $table->string('first_name');
            $table->string('last_name');
            $table->string('email')->nullable();
            $table->string('phone', 20)->nullable();
            $table->string('address')->nullable();
            $table->string('city')->nullable();
            $table->string('state', 50)->nullable();
            $table->string('zip', 10)->nullable();
            $table->date('birthday')->nullable();
            $table->date('anniversary')->nullable();
            $table->date('member_since')->nullable();
            $table->string('photo')->nullable();
            $table->foreignId('category_id')->nullable()->constrained()->nullOnDelete();
            $table->string('role')->nullable(); // member, deacon, elder, pastor, staff
            $table->text('notes')->nullable();
            $table->boolean('is_active')->default(true);
            $table->boolean('show_in_directory')->default(true);
            $table->timestamps();
            $table->index(['last_name', 'first_name']);
        });

        // ── Contact Form Submissions ─────────────────────
        Schema::create('contact_messages', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('email');
            $table->string('phone', 20)->nullable();
            $table->string('subject')->nullable();
            $table->text('message');
            $table->boolean('is_read')->default(false);
            $table->timestamps();
        });

        // ── Media Gallery ────────────────────────────────
        Schema::create('media', function (Blueprint $table) {
            $table->id();
            $table->string('title')->nullable();
            $table->string('file_path');
            $table->string('file_type', 20); // image, video, audio, document
            $table->unsignedInteger('file_size')->default(0);
            $table->string('alt_text')->nullable();
            $table->foreignId('category_id')->nullable()->constrained()->nullOnDelete();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        $tables = [
            'media', 'contact_messages', 'directory_members',
            'announcements', 'donations', 'volunteer_signups', 'volunteer_ministries',
            'reviews', 'devotionals', 'sermons',
            'bible_study_participants', 'bible_studies',
            'books', 'event_rsvps', 'events',
            'prayer_prays', 'prayer_requests',
            'blessings', 'verses', 'church_settings', 'seo_meta',
            'categories', 'admin_users',
        ];
        foreach ($tables as $t) Schema::dropIfExists($t);
    }
};
