<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Carbon\Carbon;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $now = Carbon::now();
        $today = Carbon::today();

        // ── Admin User ───────────────────────────────────
        DB::table('admin_users')->insert([
            'name' => 'Admin',
            'email' => 'admin@church.com',
            'password' => Hash::make('password'),
            'role' => 'admin',
            'created_at' => $now, 'updated_at' => $now,
        ]);

        // ── Default Categories ───────────────────────────
        $cats = [
            ['name'=>'Worship','slug'=>'worship','type'=>'event','icon'=>'⛪','color'=>'#C9A84C','sort_order'=>1],
            ['name'=>'Bible Study','slug'=>'bible-study','type'=>'event','icon'=>'📖','color'=>'#4A7C9B','sort_order'=>2],
            ['name'=>'Outreach','slug'=>'outreach','type'=>'event','icon'=>'🌍','color'=>'#4A9B6A','sort_order'=>3],
            ['name'=>'Fellowship','slug'=>'fellowship','type'=>'event','icon'=>'🤝','color'=>'#9B4A6A','sort_order'=>4],
            ['name'=>'Youth','slug'=>'youth','type'=>'event','icon'=>'🎯','color'=>'#B89A4A','sort_order'=>5],
            ['name'=>'Theology','slug'=>'theology','type'=>'book','icon'=>'📘','color'=>'#4A7C9B','sort_order'=>1],
            ['name'=>'Christian Living','slug'=>'christian-living','type'=>'book','icon'=>'📗','color'=>'#4A9B6A','sort_order'=>2],
            ['name'=>'Prayer','slug'=>'prayer','type'=>'book','icon'=>'📕','color'=>'#9B4A6A','sort_order'=>3],
            ['name'=>'Apologetics','slug'=>'apologetics','type'=>'book','icon'=>'📙','color'=>'#B89A4A','sort_order'=>4],
            ['name'=>'Gospel','slug'=>'gospel','type'=>'study','icon'=>'✝','color'=>'#C9A84C','sort_order'=>1],
            ['name'=>'Old Testament','slug'=>'old-testament','type'=>'study','icon'=>'📜','color'=>'#4A7C9B','sort_order'=>2],
            ['name'=>'Epistles','slug'=>'epistles','type'=>'study','icon'=>'✉','color'=>'#4A9B6A','sort_order'=>3],
            ['name'=>'Faith','slug'=>'faith','type'=>'sermon','icon'=>'🙏','color'=>'#C9A84C','sort_order'=>1],
            ['name'=>'Grace','slug'=>'grace','type'=>'sermon','icon'=>'💛','color'=>'#4A9B6A','sort_order'=>2],
            ['name'=>'Family','slug'=>'family','type'=>'sermon','icon'=>'👨‍👩‍👧‍👦','color'=>'#9B4A6A','sort_order'=>3],
            ['name'=>'Members','slug'=>'members','type'=>'directory','icon'=>'👤','color'=>'#4A7C9B','sort_order'=>1],
            ['name'=>'Staff','slug'=>'staff','type'=>'directory','icon'=>'💼','color'=>'#C9A84C','sort_order'=>2],
            ['name'=>'Leaders','slug'=>'leaders','type'=>'directory','icon'=>'⭐','color'=>'#4A9B6A','sort_order'=>3],
        ];
        foreach ($cats as $c) {
            DB::table('categories')->insert(array_merge($c, ['is_active'=>1,'created_at'=>$now,'updated_at'=>$now]));
        }

        // ── SEO Meta ─────────────────────────────────────
        $seo = [
            ['page_slug'=>'home','title'=>'Welcome to Our Church','description'=>'Join our faith community for worship, fellowship, and spiritual growth.'],
            ['page_slug'=>'about','title'=>'About Our Church','description'=>'Learn about our mission, vision, and leadership.'],
            ['page_slug'=>'events','title'=>'Church Events','description'=>'Upcoming church events, services, and gatherings.'],
            ['page_slug'=>'sermons','title'=>'Sermon Archive','description'=>'Listen to past sermons and be inspired by God\'s Word.'],
            ['page_slug'=>'library','title'=>'Book Library','description'=>'Browse and download Christian books and resources.'],
            ['page_slug'=>'prayers','title'=>'Prayer Wall','description'=>'Submit prayer requests and pray for others.'],
            ['page_slug'=>'giving','title'=>'Online Giving','description'=>'Support our church mission through generous giving.'],
            ['page_slug'=>'contact','title'=>'Contact Us','description'=>'Get in touch with our church family.'],
            ['page_slug'=>'directory','title'=>'Church Directory','description'=>'Connect with members of our church family.'],
        ];
        foreach ($seo as $s) {
            DB::table('seo_meta')->insert(array_merge($s, ['created_at'=>$now,'updated_at'=>$now]));
        }

        // ── Church Settings ──────────────────────────────
        $settings = [
            ['group'=>'general','key'=>'church_name','value'=>'Grace Community Church'],
            ['group'=>'general','key'=>'tagline','value'=>'Where Faith Meets Fellowship'],
            ['group'=>'general','key'=>'pastor','value'=>'Pastor David Thompson'],
            ['group'=>'general','key'=>'founded','value'=>'1987'],
            ['group'=>'general','key'=>'denomination','value'=>'Non-Denominational'],
            ['group'=>'general','key'=>'mission','value'=>'To love God, love people, and make disciples who transform the world.'],
            ['group'=>'general','key'=>'vision','value'=>'A church where everyone belongs, believes, and becomes.'],
            ['group'=>'general','key'=>'about_text','value'=>'Grace Community Church was founded in 1987 with a vision to create a welcoming space for all people to encounter God. Over the decades, we have grown from a small gathering to a thriving community of believers committed to worship, fellowship, and service.'],
            ['group'=>'contact','key'=>'address','value'=>'1234 Grace Avenue, Springfield, IL 62701'],
            ['group'=>'contact','key'=>'phone','value'=>'(217) 555-0142'],
            ['group'=>'contact','key'=>'email','value'=>'info@gracecommunity.church'],
            ['group'=>'contact','key'=>'service_times','value'=>'["Sunday: 9:00 AM & 11:00 AM","Wednesday Bible Study: 7:00 PM","Friday Youth Night: 6:30 PM"]'],
            ['group'=>'social','key'=>'facebook','value'=>'https://facebook.com/gracecommunity'],
            ['group'=>'social','key'=>'youtube','value'=>'https://youtube.com/@gracecommunity'],
            ['group'=>'social','key'=>'instagram','value'=>'https://instagram.com/gracecommunity'],
            ['group'=>'social','key'=>'twitter','value'=>''],
            ['group'=>'social','key'=>'tiktok','value'=>''],
            ['group'=>'appearance','key'=>'theme','value'=>'dark'],
            ['group'=>'appearance','key'=>'primary_color','value'=>'#C9A84C'],
            ['group'=>'appearance','key'=>'logo','value'=>''],
            ['group'=>'appearance','key'=>'favicon','value'=>''],
            ['group'=>'appearance','key'=>'hero_image','value'=>''],
            ['group'=>'features','key'=>'enable_prayers','value'=>'1'],
            ['group'=>'features','key'=>'enable_giving','value'=>'1'],
            ['group'=>'features','key'=>'enable_directory','value'=>'1'],
            ['group'=>'features','key'=>'enable_reviews','value'=>'1'],
            ['group'=>'features','key'=>'prayer_auto_approve','value'=>'0'],
            ['group'=>'features','key'=>'review_auto_approve','value'=>'0'],
        ];
        foreach ($settings as $s) {
            DB::table('church_settings')->insert(array_merge($s, ['created_at'=>$now,'updated_at'=>$now]));
        }

        // ── Sample Verses ────────────────────────────────
        $verses = [
            ['For I know the plans I have for you, declares the LORD, plans to prosper you and not to harm you, plans to give you hope and a future.', 'Jeremiah 29:11', 0],
            ['The LORD is my shepherd; I shall not want.', 'Psalm 23:1', 1],
            ['I can do all things through Christ who strengthens me.', 'Philippians 4:13', 2],
            ['Trust in the LORD with all your heart and lean not on your own understanding.', 'Proverbs 3:5', 3],
            ['Be strong and courageous. Do not be afraid; do not be discouraged, for the LORD your God will be with you wherever you go.', 'Joshua 1:9', 4],
            ['And we know that in all things God works for the good of those who love him.', 'Romans 8:28', 5],
            ['The Lord is my light and my salvation — whom shall I fear?', 'Psalm 27:1', 6],
        ];
        foreach ($verses as $v) {
            DB::table('verses')->insert(['text'=>$v[0],'reference'=>$v[1],'display_date'=>$today->copy()->addDays($v[2])->toDateString(),'is_active'=>1,'created_at'=>$now,'updated_at'=>$now]);
        }

        // ── Sample Blessings ─────────────────────────────
        DB::table('blessings')->insert([
            ['title'=>'Today\'s Blessing','text'=>'May the Lord bless you and keep you. May His face shine upon you and be gracious to you. May He turn His face toward you and give you peace.','author'=>'Numbers 6:24-26','display_date'=>$today->toDateString(),'is_active'=>1,'created_at'=>$now,'updated_at'=>$now],
            ['title'=>'Morning Grace','text'=>'May God grant you wisdom for every decision today and fill your heart with peace that surpasses all understanding.','author'=>'Philippians 4:7','display_date'=>$today->copy()->addDay()->toDateString(),'is_active'=>1,'created_at'=>$now,'updated_at'=>$now],
        ]);

        // ── Sample Prayers ───────────────────────────────
        DB::table('prayer_requests')->insert([
            ['name'=>'Sarah M.','request'=>'Please pray for my mother\'s recovery from surgery.','is_anonymous'=>0,'prayer_count'=>24,'status'=>'active','is_approved'=>1,'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'Anonymous','request'=>'Praying for guidance in a difficult career decision.','is_anonymous'=>1,'prayer_count'=>18,'status'=>'active','is_approved'=>1,'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'James K.','request'=>'Pray for our community during these difficult times.','is_anonymous'=>0,'prayer_count'=>31,'status'=>'active','is_approved'=>1,'created_at'=>$now,'updated_at'=>$now],
        ]);

        // ── Sample Events ────────────────────────────────
        DB::table('events')->insert([
            ['title'=>'Sunday Worship Service','slug'=>'sunday-worship','description'=>'Join us for praise, worship, and an inspiring message.','event_date'=>$today->copy()->next('Sunday')->toDateString(),'event_time'=>'10:00:00','end_date'=>null,'end_time'=>null,'location'=>'Main Sanctuary','category_id'=>1,'image'=>null,'is_recurring'=>1,'recurrence_pattern'=>'weekly','is_featured'=>1,'is_active'=>1,'created_at'=>$now,'updated_at'=>$now],
            ['title'=>'Youth Bible Study','slug'=>'youth-bible-study','description'=>'Interactive study for teens exploring Psalms.','event_date'=>$today->copy()->next('Wednesday')->toDateString(),'event_time'=>'18:30:00','end_date'=>null,'end_time'=>null,'location'=>'Youth Hall','category_id'=>2,'image'=>null,'is_recurring'=>1,'recurrence_pattern'=>'weekly','is_featured'=>0,'is_active'=>1,'created_at'=>$now,'updated_at'=>$now],
            ['title'=>'Community Outreach','slug'=>'community-outreach','description'=>'Serve meals and distribute clothing to those in need.','event_date'=>$today->copy()->next('Saturday')->toDateString(),'event_time'=>'09:00:00','end_date'=>null,'end_time'=>null,'location'=>'Community Center','category_id'=>3,'image'=>null,'is_recurring'=>0,'recurrence_pattern'=>null,'is_featured'=>0,'is_active'=>1,'created_at'=>$now,'updated_at'=>$now],
        ]);

        // ── Sample Books ─────────────────────────────────
        DB::table('books')->insert([
            ['title'=>'Purpose Driven Life','slug'=>'purpose-driven-life','author'=>'Rick Warren','category_id'=>7,'description'=>'A groundbreaking guide to discovering your God-given purpose.','cover_image'=>null,'pdf_path'=>null,'pages'=>334,'isbn'=>null,'has_pdf'=>0,'download_count'=>0,'is_featured'=>1,'is_active'=>1,'created_at'=>$now,'updated_at'=>$now],
            ['title'=>'Mere Christianity','slug'=>'mere-christianity','author'=>'C.S. Lewis','category_id'=>9,'description'=>'One of the most popular defenses of Christian faith ever written.','cover_image'=>null,'pdf_path'=>null,'pages'=>227,'isbn'=>null,'has_pdf'=>0,'download_count'=>0,'is_featured'=>1,'is_active'=>1,'created_at'=>$now,'updated_at'=>$now],
            ['title'=>'The Power of Prayer','slug'=>'power-of-prayer','author'=>'E.M. Bounds','category_id'=>8,'description'=>'Classic work on the practice and power of prayer.','cover_image'=>null,'pdf_path'=>null,'pages'=>192,'isbn'=>null,'has_pdf'=>0,'download_count'=>0,'is_featured'=>0,'is_active'=>1,'created_at'=>$now,'updated_at'=>$now],
        ]);

        // ── Sample Studies ───────────────────────────────
        DB::table('bible_studies')->insert([
            ['title'=>'The Gospel of John','slug'=>'gospel-of-john','description'=>'A deep dive into the life and teachings of Jesus.','category_id'=>10,'leader'=>'Pastor David','total_weeks'=>12,'current_week'=>5,'participant_count'=>34,'max_participants'=>null,'meeting_day'=>'Tuesday','meeting_time'=>'19:00:00','location'=>'Room 201','materials_pdf'=>null,'status'=>'active','is_active'=>1,'created_at'=>$now,'updated_at'=>$now],
            ['title'=>'Armor of God','slug'=>'armor-of-god','description'=>'Understanding spiritual warfare using Ephesians 6.','category_id'=>12,'leader'=>'Brother Paul','total_weeks'=>6,'current_week'=>1,'participant_count'=>28,'max_participants'=>40,'meeting_day'=>'Thursday','meeting_time'=>'18:30:00','location'=>'Fellowship Hall','materials_pdf'=>null,'status'=>'upcoming','is_active'=>1,'created_at'=>$now,'updated_at'=>$now],
        ]);

        // ── Sample Sermons ───────────────────────────────
        DB::table('sermons')->insert([
            ['title'=>'Walking in Faith','slug'=>'walking-in-faith','speaker'=>'Pastor David Thompson','description'=>'Discovering what it means to trust God in uncertain times.','sermon_date'=>$today->copy()->subWeek()->toDateString(),'duration'=>'42 min','series'=>'Faith Journey','category_id'=>13,'audio_url'=>null,'video_url'=>null,'notes_pdf'=>null,'thumbnail'=>null,'view_count'=>156,'is_featured'=>1,'is_active'=>1,'created_at'=>$now,'updated_at'=>$now],
            ['title'=>'Grace Unmeasured','slug'=>'grace-unmeasured','speaker'=>'Rev. Anna Cole','description'=>'Understanding the boundless grace of God.','sermon_date'=>$today->copy()->subWeeks(2)->toDateString(),'duration'=>'45 min','series'=>'Grace Series','category_id'=>14,'audio_url'=>null,'video_url'=>null,'notes_pdf'=>null,'thumbnail'=>null,'view_count'=>98,'is_featured'=>0,'is_active'=>1,'created_at'=>$now,'updated_at'=>$now],
        ]);

        // ── Sample Devotionals ───────────────────────────
        DB::table('devotionals')->insert([
            ['title'=>'Morning Light','verse'=>'Lamentations 3:22-23','content'=>'His mercies are new every morning. As you start this day, remember that God\'s faithfulness is your foundation. No matter what yesterday held, today is a fresh canvas of grace.','author'=>'Pastor David','display_date'=>$today->toDateString(),'is_active'=>1,'created_at'=>$now,'updated_at'=>$now],
        ]);

        // ── Sample Reviews ───────────────────────────────
        DB::table('reviews')->insert([
            ['name'=>'Rebecca L.','text'=>'This church has truly transformed my life. The community is so welcoming.','rating'=>5,'is_approved'=>1,'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'Michael T.','text'=>'The youth programs are incredible. My children love coming here!','rating'=>5,'is_approved'=>1,'created_at'=>$now,'updated_at'=>$now],
            ['name'=>'Grace W.','text'=>'Beautiful worship services and Bible study groups.','rating'=>4,'is_approved'=>1,'created_at'=>$now,'updated_at'=>$now],
        ]);

        // ── Sample Volunteer Ministries ──────────────────
        $ministries = [
            ['Worship Team','🎵','Lead worship through music.',3],
            ['Children\'s Ministry','📖','Teach our youngest members.',5],
            ['Media & Tech','🎥','Sound, lighting, and streaming.',2],
            ['Greeting Team','🤝','Welcome visitors each Sunday.',4],
            ['Food Ministry','🍞','Prepare meals for events.',6],
            ['Prayer Team','🙏','Intercede for the community.',null],
            ['Outreach','📞','Connect with the broader community.',3],
        ];
        foreach ($ministries as $m) {
            DB::table('volunteer_ministries')->insert(['name'=>$m[0],'icon'=>$m[1],'description'=>$m[2],'spots_available'=>$m[3],'is_active'=>1,'created_at'=>$now,'updated_at'=>$now]);
        }

        // ── Sample Announcements ─────────────────────────
        DB::table('announcements')->insert([
            ['title'=>'New Bible Study Starting','content'=>'Armor of God study begins next week. Sign up online or at the front desk.','priority'=>'important','start_date'=>$today->toDateString(),'end_date'=>$today->copy()->addWeeks(2)->toDateString(),'is_active'=>1,'created_at'=>$now,'updated_at'=>$now],
        ]);

        // ── Sample Directory Members ─────────────────────
        DB::table('directory_members')->insert([
            ['first_name'=>'David','last_name'=>'Thompson','email'=>'pastor@gracechurch.com','phone'=>'(217) 555-0001','role'=>'pastor','category_id'=>17,'member_since'=>'2000-01-01','is_active'=>1,'show_in_directory'=>1,'created_at'=>$now,'updated_at'=>$now],
            ['first_name'=>'Mary','last_name'=>'Johnson','email'=>'mary@gracechurch.com','phone'=>'(217) 555-0002','role'=>'staff','category_id'=>17,'member_since'=>'2010-06-15','is_active'=>1,'show_in_directory'=>1,'created_at'=>$now,'updated_at'=>$now],
        ]);
    }
}
