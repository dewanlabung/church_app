#!/bin/bash
# ═══════════════════════════════════════════════════════
# Church Platform Installer for Laravel 10
# ═══════════════════════════════════════════════════════
echo "✝ Church Platform Setup"
echo "========================="

cd "$(dirname "$0")"

if [ ! -f "artisan" ]; then
    echo "❌ No artisan found. Run this from your Laravel root."
    exit 1
fi

echo "✅ Laravel detected"

# Check .env
if [ ! -f ".env" ]; then
    echo "Creating .env from .env.example..."
    cp .env.example .env
    php artisan key:generate --force
    echo ""
    echo "⚠️  Edit .env with your database credentials, then run this again."
    exit 0
fi

# Register middleware
echo "🔧 Registering AdminAuth middleware..."
if grep -q "AdminAuth" app/Http/Kernel.php 2>/dev/null; then
    echo "   Already registered"
else
    sed -i "/'verified'/a\\        'admin' => \\\\App\\\\Http\\\\Middleware\\\\AdminAuth::class," app/Http/Kernel.php 2>/dev/null && echo "   ✅ Done" || echo "   ⚠️  Add manually: 'admin' => AdminAuth::class in Kernel.php"
fi

# CSRF exception
echo "🔧 Adding CSRF exception for admin API..."
if grep -q "admin/api" app/Http/Middleware/VerifyCsrfToken.php 2>/dev/null; then
    echo "   Already configured"
else
    sed -i "s|protected \$except = \[|protected \$except = [\n        'admin/api/*',|" app/Http/Middleware/VerifyCsrfToken.php 2>/dev/null && echo "   ✅ Done" || echo "   ⚠️  Add 'admin/api/*' to VerifyCsrfToken \$except array"
fi

# Directories
echo "📁 Creating directories..."
mkdir -p public/uploads/books public/uploads/covers public/uploads/photos
chmod -R 775 storage bootstrap/cache public/uploads 2>/dev/null

# Storage link
echo "🔗 Storage link..."
php artisan storage:link 2>/dev/null || true

# Migrate
echo "🗄️  Running migrations..."
php artisan migrate --force

# Seed
echo "🌱 Seeding data..."
php artisan db:seed --force

# Cache
echo "🧹 Clearing caches..."
php artisan config:clear
php artisan cache:clear
php artisan route:clear
php artisan view:clear

echo ""
echo "✅ ═══════════════════════════════════════════"
echo "   Church Platform Installed!"
echo "   ═══════════════════════════════════════════"
echo ""
echo "   🌐 Site:  your-domain.com/"
echo "   🔐 Admin: your-domain.com/admin"
echo "   📧 Login: admin@church.com"
echo "   🔑 Pass:  password"
echo ""
