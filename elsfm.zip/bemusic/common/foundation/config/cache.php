<?php

return [
    'default' => env('CACHE_STORE', 'file'),
];
