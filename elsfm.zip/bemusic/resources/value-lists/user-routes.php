<?php

return [
    'login',
    'register',
    'popular-genres',
    'popular-albums',
    'top-50',
    'new-releases',
    'library/songs',
    'library/albums',
    'library/artists',
    'account-settings',
    'admin/appearance',
    'admin/users',
    'admin/settings/authentication',
    'admin/settings/branding',
    'admin/settings/cache',
    'admin/settings/providers',
    'admin/settings/player',
    'admin/settings/player',
    'admin/settings/genres',
    'admin/groups',
];
