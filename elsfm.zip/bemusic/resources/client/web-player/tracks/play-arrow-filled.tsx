import {createSvgIcon} from '@ui/icons/create-svg-icon';

export const PlayArrowFilledIcon = createSvgIcon(
  <path d="M8 19V5l11 7Z" />,
  'PlayArrowFilled',
);
