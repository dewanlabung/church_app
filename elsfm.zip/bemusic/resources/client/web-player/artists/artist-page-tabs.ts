export const artistPageTabs = {
  discography: '1',
  similar: '2',
  about: '3',
  tracks: '4',
  albums: '5',
  followers: '6',
} as const;
