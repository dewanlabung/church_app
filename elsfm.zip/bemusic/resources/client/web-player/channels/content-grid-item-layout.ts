export type ContentGridItemLayout = 'default' | 'compact';
