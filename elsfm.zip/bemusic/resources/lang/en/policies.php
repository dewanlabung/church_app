<?php

return [
    'minutes_exceeded' =>
        'You have exceeded the total number of minutes allowed for your account. To upload more tracks you will need to upgrade to a higher plan.',
    'count_description' =>
        'Maximum number of :resources user will be able to create. Leave empty for unlimited.',
];
