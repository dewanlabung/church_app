<?php

return [
    App\Services\Settings\Validators\SpotifyCredentialsValidator::class,
    App\Services\Settings\Validators\LastfmCredentialsValidator::class,
    App\Services\Settings\Validators\YoutubeCredentialsValidator::class,
    App\Services\Settings\Validators\WikipediaCredentialsValidator::class,
];
