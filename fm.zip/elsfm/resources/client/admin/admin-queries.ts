import {commonAdminQueries} from '@common/admin/common-admin-queries';

export const adminQueries = {
  ...commonAdminQueries,
};
