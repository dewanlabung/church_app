<?php

use Common\Core\Application;

return Application::create(
    basePath: dirname(__DIR__),
    providers: [
        //
    ],
);
