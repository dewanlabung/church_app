<?php

return [
    'release' => 'xx',
];
