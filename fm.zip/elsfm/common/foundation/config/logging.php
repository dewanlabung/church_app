<?php

return [
    'channels' => [
        'sentry' => [
            'driver' => 'sentry',
            'level' => 'error',
        ],
    ],
];
