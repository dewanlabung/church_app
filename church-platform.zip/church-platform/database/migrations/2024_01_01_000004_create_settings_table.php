<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->id();
            $table->string('church_name')->default('My Church');
            $table->text('church_description')->nullable();
            $table->string('church_address')->nullable();
            $table->string('church_phone')->nullable();
            $table->string('church_email')->nullable();
            $table->string('church_logo')->nullable();
            $table->string('church_banner')->nullable();
            $table->string('facebook_url')->nullable();
            $table->string('youtube_url')->nullable();
            $table->string('instagram_url')->nullable();
            $table->string('twitter_url')->nullable();
            $table->string('tiktok_url')->nullable();
            $table->text('service_times')->nullable();
            $table->string('pastor_name')->nullable();
            $table->text('pastor_bio')->nullable();
            $table->string('pastor_photo')->nullable();
            $table->string('timezone')->default('UTC');
            $table->string('meta_title')->nullable();
            $table->text('meta_description')->nullable();
            $table->string('meta_keywords')->nullable();
            $table->text('google_analytics_id')->nullable();
            $table->text('custom_css')->nullable();
            $table->text('custom_js')->nullable();
            $table->string('primary_color')->default('#4F46E5');
            $table->string('secondary_color')->default('#7C3AED');
            $table->string('donation_link')->nullable();
            $table->text('footer_text')->nullable();
            $table->boolean('maintenance_mode')->default(false);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('settings');
    }
};
